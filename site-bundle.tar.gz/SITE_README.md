# Python Course Website

公开访问版的 Microsoft Python 课程学习网站。

- 64 个视频课程
- 15 个数据工具 Notebook
- 10 组代码挑战，共 19 个作业文件
- 官方简体中文与英文字幕

课程原始项目：
https://github.com/microsoft/c9-python-getting-started
