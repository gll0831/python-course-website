window.COURSE_DATA = {
  "generatedAt": "2026-09-18T02:46:28.195Z",
  "source": {
    "repository": "https://github.com/microsoft/c9-python-getting-started",
    "learn": "https://learn.microsoft.com/en-us/shows/intro-to-python-development/"
  },
  "tracks": [
    {
      "id": "basics",
      "showUid": "intro-to-python-development",
      "title": "Python for Beginners",
      "shortTitle": "Python 基础",
      "description": "从运行环境、变量、条件、循环到函数、模块、错误处理和 API 调用，建立完整的 Python 基础。",
      "sourceUrl": "https://learn.microsoft.com/en-us/shows/intro-to-python-development/",
      "repoUrl": "../python-for-beginners/README.md",
      "accent": "blue",
      "lessonCount": 44,
      "videoCount": 44,
      "durationMs": 16535000,
      "lessons": [
        {
          "id": "6463c48a-caed-440e-94cc-3c024bc4e228",
          "track": "basics",
          "number": 1,
          "title": "Programming with Python",
          "rawTitle": "Python for Beginners [1 of 44] Programming with Python",
          "description": "Python 基础第 1 课",
          "durationMs": 257000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-6463c48a-caed-440e-94cc-3c024bc4e228/python1_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-6463c48a-caed-440e-94cc-3c024bc4e228/python1_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-6463c48a-caed-440e-94cc-3c024bc4e228/python1.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-1-of-44-programming-with-python/",
          "publishDate": "2019-09-16T20:49:31.309Z",
          "captions": {
            "zh-cn": "captions/zh-cn/6463c48a-caed-440e-94cc-3c024bc4e228.vtt",
            "en-us": "captions/en-us/6463c48a-caed-440e-94cc-3c024bc4e228.vtt"
          }
        },
        {
          "id": "538eb8eb-f618-4d22-8bbe-15405582f5a6",
          "track": "basics",
          "number": 2,
          "title": "Introducing Python",
          "rawTitle": "Python for Beginners [2 of 44] Introducing Python",
          "description": "Python 基础第 2 课",
          "durationMs": 189000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-538eb8eb-f618-4d22-8bbe-15405582f5a6/introducingpython_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-538eb8eb-f618-4d22-8bbe-15405582f5a6/introducingpython_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-538eb8eb-f618-4d22-8bbe-15405582f5a6/introducingpython.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-2-of-44-introducing-python/",
          "publishDate": "2019-09-16T20:50:20.852Z",
          "captions": {
            "zh-cn": "captions/zh-cn/538eb8eb-f618-4d22-8bbe-15405582f5a6.vtt",
            "en-us": "captions/en-us/538eb8eb-f618-4d22-8bbe-15405582f5a6.vtt"
          }
        },
        {
          "id": "2d9902dc-bce0-4929-a0c0-22ebfe8e31a3",
          "track": "basics",
          "number": 3,
          "title": "Getting Started",
          "rawTitle": "Python for Beginners [3 of 44] Getting Started",
          "description": "Python 基础第 3 课",
          "durationMs": 177000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-2d9902dc-bce0-4929-a0c0-22ebfe8e31a3/gettingstarted_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-2d9902dc-bce0-4929-a0c0-22ebfe8e31a3/gettingstarted_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-2d9902dc-bce0-4929-a0c0-22ebfe8e31a3/gettingstarted.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-3-of-44-getting-started/",
          "publishDate": "2019-09-16T20:50:37.87Z",
          "captions": {
            "zh-cn": "captions/zh-cn/2d9902dc-bce0-4929-a0c0-22ebfe8e31a3.vtt",
            "en-us": "captions/en-us/2d9902dc-bce0-4929-a0c0-22ebfe8e31a3.vtt"
          }
        },
        {
          "id": "b04c9161-941c-4799-8c71-b6c653321798",
          "track": "basics",
          "number": 4,
          "title": "Configuring Visual Studio Code",
          "rawTitle": "Python for Beginners [4 of 44] Configuring Visual Studio Code",
          "description": "Python 基础第 4 课",
          "durationMs": 169000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-b04c9161-941c-4799-8c71-b6c653321798/configuringvisualstudiocode_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-b04c9161-941c-4799-8c71-b6c653321798/configuringvisualstudiocode_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-b04c9161-941c-4799-8c71-b6c653321798/configuringvisualstudiocode.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-4-of-44-configuring-visual-studio-code/",
          "publishDate": "2019-09-16T20:50:42.546Z",
          "captions": {
            "zh-cn": "captions/zh-cn/b04c9161-941c-4799-8c71-b6c653321798.vtt",
            "en-us": "captions/en-us/b04c9161-941c-4799-8c71-b6c653321798.vtt"
          }
        },
        {
          "id": "92b65904-6516-42e7-aef4-2ffa1eb8cf86",
          "track": "basics",
          "number": 5,
          "title": "Using Print",
          "rawTitle": "Python for Beginners [5 of 44] Using Print",
          "description": "Python 基础第 5 课",
          "durationMs": 208000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-92b65904-6516-42e7-aef4-2ffa1eb8cf86/pythonprint5_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-92b65904-6516-42e7-aef4-2ffa1eb8cf86/pythonprint5_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-92b65904-6516-42e7-aef4-2ffa1eb8cf86/pythonprint5.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-5-of-44-using-print/",
          "publishDate": "2019-09-16T20:51:12.613Z",
          "captions": {
            "zh-cn": "captions/zh-cn/92b65904-6516-42e7-aef4-2ffa1eb8cf86.vtt",
            "en-us": "captions/en-us/92b65904-6516-42e7-aef4-2ffa1eb8cf86.vtt"
          }
        },
        {
          "id": "862f08d9-24ae-4b65-bed4-167402f3f442",
          "track": "basics",
          "number": 6,
          "title": "Demo: Hello, World",
          "rawTitle": "Python for Beginners [6 of 44] Demo: Hello, World",
          "description": "Python 基础第 6 课",
          "durationMs": 359000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-862f08d9-24ae-4b65-bed4-167402f3f442/demohelloworld_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-862f08d9-24ae-4b65-bed4-167402f3f442/demohelloworld_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-862f08d9-24ae-4b65-bed4-167402f3f442/demohelloworld.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-6-of-44-demo-hello-world/",
          "publishDate": "2019-09-16T20:51:20.128Z",
          "captions": {
            "zh-cn": "captions/zh-cn/862f08d9-24ae-4b65-bed4-167402f3f442.vtt",
            "en-us": "captions/en-us/862f08d9-24ae-4b65-bed4-167402f3f442.vtt"
          }
        },
        {
          "id": "1de7a768-36d3-4248-81e2-48e5f31e2789",
          "track": "basics",
          "number": 7,
          "title": "Comments",
          "rawTitle": "Python for Beginners [7 of 44] Comments",
          "description": "Python 基础第 7 课",
          "durationMs": 183000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-1de7a768-36d3-4248-81e2-48e5f31e2789/comments_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-1de7a768-36d3-4248-81e2-48e5f31e2789/comments_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-1de7a768-36d3-4248-81e2-48e5f31e2789/comments.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-7-of-44-comments/",
          "publishDate": "2019-09-16T20:51:30.311Z",
          "captions": {
            "zh-cn": "captions/zh-cn/1de7a768-36d3-4248-81e2-48e5f31e2789.vtt",
            "en-us": "captions/en-us/1de7a768-36d3-4248-81e2-48e5f31e2789.vtt"
          }
        },
        {
          "id": "01a831f8-ec68-4579-b616-bbacc3e43d07",
          "track": "basics",
          "number": 8,
          "title": "Demo: Comments",
          "rawTitle": "Python for Beginners [8 of 44] Demo: Comments",
          "description": "Python 基础第 8 课",
          "durationMs": 147000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-01a831f8-ec68-4579-b616-bbacc3e43d07/democomments_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-01a831f8-ec68-4579-b616-bbacc3e43d07/democomments_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-01a831f8-ec68-4579-b616-bbacc3e43d07/democomments.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-8-of-44-demo-comments/",
          "publishDate": "2019-09-16T20:51:43.385Z",
          "captions": {
            "zh-cn": "captions/zh-cn/01a831f8-ec68-4579-b616-bbacc3e43d07.vtt",
            "en-us": "captions/en-us/01a831f8-ec68-4579-b616-bbacc3e43d07.vtt"
          }
        },
        {
          "id": "59d40cfd-0ca4-450b-b5c2-4df12b9ecb5d",
          "track": "basics",
          "number": 9,
          "title": "String Concepts",
          "rawTitle": "Python for Beginners [9 of 44] String Concepts",
          "description": "Python 基础第 9 课",
          "durationMs": 280000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-59d40cfd-0ca4-450b-b5c2-4df12b9ecb5d/stringconcepts_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-59d40cfd-0ca4-450b-b5c2-4df12b9ecb5d/stringconcepts_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-59d40cfd-0ca4-450b-b5c2-4df12b9ecb5d/stringconcepts.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-9-of-44-string-concepts/",
          "publishDate": "2019-09-17T13:06:38.254Z",
          "captions": {
            "zh-cn": "captions/zh-cn/59d40cfd-0ca4-450b-b5c2-4df12b9ecb5d.vtt",
            "en-us": "captions/en-us/59d40cfd-0ca4-450b-b5c2-4df12b9ecb5d.vtt"
          }
        },
        {
          "id": "712cc386-4857-4db1-83ff-0aa6b054261d",
          "track": "basics",
          "number": 10,
          "title": "Demo: Strings",
          "rawTitle": "Python for Beginners [10 of 44] Demo: Strings",
          "description": "Python 基础第 10 课",
          "durationMs": 268000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-712cc386-4857-4db1-83ff-0aa6b054261d/demostrings_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-712cc386-4857-4db1-83ff-0aa6b054261d/demostrings_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-712cc386-4857-4db1-83ff-0aa6b054261d/demostrings.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-10-of-44-demo-strings/",
          "publishDate": "2019-09-17T13:06:47.801Z",
          "captions": {
            "zh-cn": "captions/zh-cn/712cc386-4857-4db1-83ff-0aa6b054261d.vtt",
            "en-us": "captions/en-us/712cc386-4857-4db1-83ff-0aa6b054261d.vtt"
          }
        },
        {
          "id": "9412cc06-4d8c-421c-bb6e-889b975725bb",
          "track": "basics",
          "number": 11,
          "title": "Formatting Strings",
          "rawTitle": "Python for Beginners [11 of 44] Formatting Strings",
          "description": "Python 基础第 11 课",
          "durationMs": 248000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-9412cc06-4d8c-421c-bb6e-889b975725bb/formattingstrings_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-9412cc06-4d8c-421c-bb6e-889b975725bb/formattingstrings_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-9412cc06-4d8c-421c-bb6e-889b975725bb/formattingstrings.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-11-of-44-formatting-strings/",
          "publishDate": "2019-09-17T13:06:56.56Z",
          "captions": {
            "zh-cn": "captions/zh-cn/9412cc06-4d8c-421c-bb6e-889b975725bb.vtt",
            "en-us": "captions/en-us/9412cc06-4d8c-421c-bb6e-889b975725bb.vtt"
          }
        },
        {
          "id": "dccb4fdc-8fa8-4178-9cb8-d5e5a0ca1798",
          "track": "basics",
          "number": 12,
          "title": "Demo: Formatting Strings",
          "rawTitle": "Python for Beginners [12 of 44] Demo: Formatting Strings",
          "description": "Python 基础第 12 课",
          "durationMs": 228000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-dccb4fdc-8fa8-4178-9cb8-d5e5a0ca1798/demoformattingstrings_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-dccb4fdc-8fa8-4178-9cb8-d5e5a0ca1798/demoformattingstrings_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-dccb4fdc-8fa8-4178-9cb8-d5e5a0ca1798/demoformattingstrings.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-12-of-44-demo-formatting-strings/",
          "publishDate": "2019-09-17T13:07:11.612Z",
          "captions": {
            "zh-cn": "captions/zh-cn/dccb4fdc-8fa8-4178-9cb8-d5e5a0ca1798.vtt",
            "en-us": "captions/en-us/dccb4fdc-8fa8-4178-9cb8-d5e5a0ca1798.vtt"
          }
        },
        {
          "id": "3bbc2ac8-137d-460a-8c8d-79e0e7a179ad",
          "track": "basics",
          "number": 13,
          "title": "Numeric Data Types",
          "rawTitle": "Python for Beginners [13 of 44] Numeric Data Types",
          "description": "Python 基础第 13 课",
          "durationMs": 350000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-3bbc2ac8-137d-460a-8c8d-79e0e7a179ad/numericdatatypes_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-3bbc2ac8-137d-460a-8c8d-79e0e7a179ad/numericdatatypes_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-3bbc2ac8-137d-460a-8c8d-79e0e7a179ad/numericdatatypes.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-13-of-44-numeric-data-types/",
          "publishDate": "2019-09-17T13:07:23.679Z",
          "captions": {
            "zh-cn": "captions/zh-cn/3bbc2ac8-137d-460a-8c8d-79e0e7a179ad.vtt",
            "en-us": "captions/en-us/3bbc2ac8-137d-460a-8c8d-79e0e7a179ad.vtt"
          }
        },
        {
          "id": "fda2c5d3-dc47-47f5-bd3b-e83bbd8e6eca",
          "track": "basics",
          "number": 14,
          "title": "Demo: Numbers",
          "rawTitle": "Python for Beginners [14 of 44] Demo: Numbers",
          "description": "Python 基础第 14 课",
          "durationMs": 360000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-fda2c5d3-dc47-47f5-bd3b-e83bbd8e6eca/demonumbers_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-fda2c5d3-dc47-47f5-bd3b-e83bbd8e6eca/demonumbers_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-fda2c5d3-dc47-47f5-bd3b-e83bbd8e6eca/demonumbers.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-14-of-44-demo-numbers/",
          "publishDate": "2019-09-17T13:07:36.791Z",
          "captions": {
            "zh-cn": "captions/zh-cn/fda2c5d3-dc47-47f5-bd3b-e83bbd8e6eca.vtt",
            "en-us": "captions/en-us/fda2c5d3-dc47-47f5-bd3b-e83bbd8e6eca.vtt"
          }
        },
        {
          "id": "c18acd93-fec6-4ed9-8a85-dbb00892bf24",
          "track": "basics",
          "number": 15,
          "title": "Date Data Types",
          "rawTitle": "Python for Beginners [15 of 44] Date Data Types",
          "description": "Python 基础第 15 课",
          "durationMs": 441000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c18acd93-fec6-4ed9-8a85-dbb00892bf24/datedatatypes_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c18acd93-fec6-4ed9-8a85-dbb00892bf24/datedatatypes_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c18acd93-fec6-4ed9-8a85-dbb00892bf24/datedatatypes.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-15-of-44-date-data-types/",
          "publishDate": "2019-09-17T13:07:52.952Z",
          "captions": {
            "zh-cn": "captions/zh-cn/c18acd93-fec6-4ed9-8a85-dbb00892bf24.vtt",
            "en-us": "captions/en-us/c18acd93-fec6-4ed9-8a85-dbb00892bf24.vtt"
          }
        },
        {
          "id": "a9685d59-4b61-49a4-bb9b-750589f900b3",
          "track": "basics",
          "number": 16,
          "title": "Demo: Dates",
          "rawTitle": "Python for Beginners [16 of 44] Demo: Dates",
          "description": "Python 基础第 16 课",
          "durationMs": 520000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-a9685d59-4b61-49a4-bb9b-750589f900b3/demodates_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-a9685d59-4b61-49a4-bb9b-750589f900b3/demodates_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-a9685d59-4b61-49a4-bb9b-750589f900b3/demodates.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-16-of-44-demo-dates/",
          "publishDate": "2019-09-17T13:08:02.892Z",
          "captions": {
            "zh-cn": "captions/zh-cn/a9685d59-4b61-49a4-bb9b-750589f900b3.vtt",
            "en-us": "captions/en-us/a9685d59-4b61-49a4-bb9b-750589f900b3.vtt"
          }
        },
        {
          "id": "a22d9835-41ae-4aa0-aba3-132d6f90c3e0",
          "track": "basics",
          "number": 17,
          "title": "Error Handling",
          "rawTitle": "Python for Beginners [17 of 44] Error Handling",
          "description": "Python 基础第 17 课",
          "durationMs": 773000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-a22d9835-41ae-4aa0-aba3-132d6f90c3e0/errorhandling_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-a22d9835-41ae-4aa0-aba3-132d6f90c3e0/errorhandling_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-a22d9835-41ae-4aa0-aba3-132d6f90c3e0/errorhandling.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-17-of-44-error-handling/",
          "publishDate": "2019-09-17T13:08:16.211Z",
          "captions": {
            "zh-cn": "captions/zh-cn/a22d9835-41ae-4aa0-aba3-132d6f90c3e0.vtt",
            "en-us": "captions/en-us/a22d9835-41ae-4aa0-aba3-132d6f90c3e0.vtt"
          }
        },
        {
          "id": "42a4e551-14da-4d76-b19e-c42e849f701b",
          "track": "basics",
          "number": 18,
          "title": "Demo: Error Handling",
          "rawTitle": "Python for Beginners [18 of 44] Demo: Error Handling",
          "description": "Python 基础第 18 课",
          "durationMs": 237000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-42a4e551-14da-4d76-b19e-c42e849f701b/demoerrorhandling_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-42a4e551-14da-4d76-b19e-c42e849f701b/demoerrorhandling_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-42a4e551-14da-4d76-b19e-c42e849f701b/demoerrorhandling.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-18-of-44-demo-error-handling/",
          "publishDate": "2019-09-17T13:08:32.567Z",
          "captions": {
            "zh-cn": "captions/zh-cn/42a4e551-14da-4d76-b19e-c42e849f701b.vtt",
            "en-us": "captions/en-us/42a4e551-14da-4d76-b19e-c42e849f701b.vtt"
          }
        },
        {
          "id": "e68325a9-00dc-4953-8c5c-15b5db0f08dd",
          "track": "basics",
          "number": 19,
          "title": "Conditional Logic",
          "rawTitle": "Python for Beginners [19 of 44] Conditional Logic",
          "description": "Python 基础第 19 课",
          "durationMs": 292000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-e68325a9-00dc-4953-8c5c-15b5db0f08dd/conditionallogic_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-e68325a9-00dc-4953-8c5c-15b5db0f08dd/conditionallogic_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-e68325a9-00dc-4953-8c5c-15b5db0f08dd/conditionallogic.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-19-of-44-conditional-logic/",
          "publishDate": "2019-09-18T13:00:35Z",
          "captions": {
            "zh-cn": "captions/zh-cn/e68325a9-00dc-4953-8c5c-15b5db0f08dd.vtt",
            "en-us": "captions/en-us/e68325a9-00dc-4953-8c5c-15b5db0f08dd.vtt"
          }
        },
        {
          "id": "192c6172-ea32-4f4d-891e-7680d37bbfd2",
          "track": "basics",
          "number": 20,
          "title": "Demo: Conditional Logic",
          "rawTitle": "Python for Beginners [20 of 44] Demo: Conditional Logic",
          "description": "Python 基础第 20 课",
          "durationMs": 302000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-192c6172-ea32-4f4d-891e-7680d37bbfd2/democonditionallogic_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-192c6172-ea32-4f4d-891e-7680d37bbfd2/democonditionallogic_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-192c6172-ea32-4f4d-891e-7680d37bbfd2/democonditionallogic.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-20-of-44-demo-conditional-logic/",
          "publishDate": "2019-09-18T13:00:36.646Z",
          "captions": {
            "zh-cn": "captions/zh-cn/192c6172-ea32-4f4d-891e-7680d37bbfd2.vtt",
            "en-us": "captions/en-us/192c6172-ea32-4f4d-891e-7680d37bbfd2.vtt"
          }
        },
        {
          "id": "54e90155-459f-454f-a201-493346b7c174",
          "track": "basics",
          "number": 21,
          "title": "Handling Multiple Conditions",
          "rawTitle": "Python for Beginners [21 of 44] Handling Multiple Conditions",
          "description": "Python 基础第 21 课",
          "durationMs": 356000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-54e90155-459f-454f-a201-493346b7c174/handlingmultipleconditions_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-54e90155-459f-454f-a201-493346b7c174/handlingmultipleconditions_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-54e90155-459f-454f-a201-493346b7c174/handlingmultipleconditions.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-21-of-44-handling-multiple-conditions/",
          "publishDate": "2019-09-18T13:00:41.897Z",
          "captions": {
            "zh-cn": "captions/zh-cn/54e90155-459f-454f-a201-493346b7c174.vtt",
            "en-us": "captions/en-us/54e90155-459f-454f-a201-493346b7c174.vtt"
          }
        },
        {
          "id": "2788709a-4868-48eb-8017-e6e243918426",
          "track": "basics",
          "number": 22,
          "title": "Demo: Multiple Conditions",
          "rawTitle": "Python for Beginners [22 of 44] Demo: Multiple Conditions",
          "description": "Python 基础第 22 课",
          "durationMs": 501000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-2788709a-4868-48eb-8017-e6e243918426/demomultipleconditions_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-2788709a-4868-48eb-8017-e6e243918426/demomultipleconditions_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-2788709a-4868-48eb-8017-e6e243918426/demomultipleconditions.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-22-of-44-demo-multiple-conditions/",
          "publishDate": "2019-09-18T13:00:47Z",
          "captions": {
            "zh-cn": "captions/zh-cn/2788709a-4868-48eb-8017-e6e243918426.vtt",
            "en-us": "captions/en-us/2788709a-4868-48eb-8017-e6e243918426.vtt"
          }
        },
        {
          "id": "c4e6dc54-bae7-445f-9561-43e1ae053b00",
          "track": "basics",
          "number": 23,
          "title": "Complex Conditions",
          "rawTitle": "Python for Beginners [23 of 44] Complex Conditions",
          "description": "Python 基础第 23 课",
          "durationMs": 248000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c4e6dc54-bae7-445f-9561-43e1ae053b00/complexconditionchecks_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c4e6dc54-bae7-445f-9561-43e1ae053b00/complexconditionchecks_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c4e6dc54-bae7-445f-9561-43e1ae053b00/complexconditionchecks.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-23-of-44-complex-conditions/",
          "publishDate": "2019-09-18T13:00:48.352Z",
          "captions": {
            "zh-cn": "captions/zh-cn/c4e6dc54-bae7-445f-9561-43e1ae053b00.vtt",
            "en-us": "captions/en-us/c4e6dc54-bae7-445f-9561-43e1ae053b00.vtt"
          }
        },
        {
          "id": "59911d15-cc30-4232-b8b5-dd69df1f1ab4",
          "track": "basics",
          "number": 24,
          "title": "Demo: Complex Conditions",
          "rawTitle": "Python for Beginners [24 of 44] Demo: Complex Conditions",
          "description": "Python 基础第 24 课",
          "durationMs": 324000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-59911d15-cc30-4232-b8b5-dd69df1f1ab4/democomplexconditions_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-59911d15-cc30-4232-b8b5-dd69df1f1ab4/democomplexconditions_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-59911d15-cc30-4232-b8b5-dd69df1f1ab4/democomplexconditions.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-24-of-44-demo-complex-conditions/",
          "publishDate": "2019-09-18T13:01:01.716Z",
          "captions": {
            "zh-cn": "captions/zh-cn/59911d15-cc30-4232-b8b5-dd69df1f1ab4.vtt",
            "en-us": "captions/en-us/59911d15-cc30-4232-b8b5-dd69df1f1ab4.vtt"
          }
        },
        {
          "id": "51c06203-bf6a-43b6-a130-6266cb600ffc",
          "track": "basics",
          "number": 25,
          "title": "Collections",
          "rawTitle": "Python for Beginners [25 of 44] Collections",
          "description": "Python 基础第 25 课",
          "durationMs": 686000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-51c06203-bf6a-43b6-a130-6266cb600ffc/collections_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-51c06203-bf6a-43b6-a130-6266cb600ffc/25_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-51c06203-bf6a-43b6-a130-6266cb600ffc/25.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-25-of-44-collections/",
          "publishDate": "2019-09-18T13:01:07.138Z",
          "captions": {
            "zh-cn": "captions/zh-cn/51c06203-bf6a-43b6-a130-6266cb600ffc.vtt",
            "en-us": "captions/en-us/51c06203-bf6a-43b6-a130-6266cb600ffc.vtt"
          }
        },
        {
          "id": "41363296-5de1-4a24-8404-90b8ce1a83d0",
          "track": "basics",
          "number": 26,
          "title": "Demo: Collections",
          "rawTitle": "Python for Beginners [26 of 44] Demo: Collections",
          "description": "Python 基础第 26 课",
          "durationMs": 241000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-41363296-5de1-4a24-8404-90b8ce1a83d0/democollections_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-41363296-5de1-4a24-8404-90b8ce1a83d0/26_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-41363296-5de1-4a24-8404-90b8ce1a83d0/26.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-26-of-44-demo-collections/",
          "publishDate": "2019-09-18T13:01:14.58Z",
          "captions": {
            "zh-cn": "captions/zh-cn/41363296-5de1-4a24-8404-90b8ce1a83d0.vtt",
            "en-us": "captions/en-us/41363296-5de1-4a24-8404-90b8ce1a83d0.vtt"
          }
        },
        {
          "id": "31a0c5d8-c056-4d59-a700-1dd94a902cf8",
          "track": "basics",
          "number": 27,
          "title": "Loops",
          "rawTitle": "Python for Beginners [27 of 44] Loops",
          "description": "Python 基础第 27 课",
          "durationMs": 329000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-31a0c5d8-c056-4d59-a700-1dd94a902cf8/loops_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-31a0c5d8-c056-4d59-a700-1dd94a902cf8/loops_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-31a0c5d8-c056-4d59-a700-1dd94a902cf8/loops.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-27-of-44-loops/",
          "publishDate": "2019-09-18T13:01:22.366Z",
          "captions": {
            "zh-cn": "captions/zh-cn/31a0c5d8-c056-4d59-a700-1dd94a902cf8.vtt",
            "en-us": "captions/en-us/31a0c5d8-c056-4d59-a700-1dd94a902cf8.vtt"
          }
        },
        {
          "id": "173578a6-989c-4bdb-ae7d-ce61475b1896",
          "track": "basics",
          "number": 28,
          "title": "Demo: Loops",
          "rawTitle": "Python for Beginners [28 of 44] Demo: Loops",
          "description": "Python 基础第 28 课",
          "durationMs": 184000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-173578a6-989c-4bdb-ae7d-ce61475b1896/demoloops_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-173578a6-989c-4bdb-ae7d-ce61475b1896/demoloops_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-173578a6-989c-4bdb-ae7d-ce61475b1896/demoloops.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-28-of-44-demo-loops/",
          "publishDate": "2019-09-18T13:01:27.702Z",
          "captions": {
            "zh-cn": "captions/zh-cn/173578a6-989c-4bdb-ae7d-ce61475b1896.vtt",
            "en-us": "captions/en-us/173578a6-989c-4bdb-ae7d-ce61475b1896.vtt"
          }
        },
        {
          "id": "75a9db35-0dcb-4df0-b6eb-eb19701afa17",
          "track": "basics",
          "number": 29,
          "title": "Introducing Functions",
          "rawTitle": "Python for Beginners [29 of 44] Introducing Functions",
          "description": "Python 基础第 29 课",
          "durationMs": 608000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-75a9db35-0dcb-4df0-b6eb-eb19701afa17/introducingfunctions_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-75a9db35-0dcb-4df0-b6eb-eb19701afa17/introducingfunctions_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-75a9db35-0dcb-4df0-b6eb-eb19701afa17/introducingfunctions.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-29-of-44-introducing-functions/",
          "publishDate": "2019-09-18T13:01:33.094Z",
          "captions": {
            "zh-cn": "captions/zh-cn/75a9db35-0dcb-4df0-b6eb-eb19701afa17.vtt",
            "en-us": "captions/en-us/75a9db35-0dcb-4df0-b6eb-eb19701afa17.vtt"
          }
        },
        {
          "id": "2e9f48ad-28bf-49c6-9224-a6f657aaf891",
          "track": "basics",
          "number": 30,
          "title": "Demo: Functions",
          "rawTitle": "Python for Beginners [30 of 44] Demo: Functions",
          "description": "Python 基础第 30 课",
          "durationMs": 467000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-2e9f48ad-28bf-49c6-9224-a6f657aaf891/demofunctions_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-2e9f48ad-28bf-49c6-9224-a6f657aaf891/demofunctions_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-2e9f48ad-28bf-49c6-9224-a6f657aaf891/demofunctions.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-30-of-44-demo-functions/",
          "publishDate": "2019-09-18T13:01:37Z",
          "captions": {
            "zh-cn": "captions/zh-cn/2e9f48ad-28bf-49c6-9224-a6f657aaf891.vtt",
            "en-us": "captions/en-us/2e9f48ad-28bf-49c6-9224-a6f657aaf891.vtt"
          }
        },
        {
          "id": "709d1e4d-5e7c-416a-b481-2377faea3545",
          "track": "basics",
          "number": 31,
          "title": "Parameterized functions",
          "rawTitle": "Python for Beginners [31 of 44] Parameterized functions",
          "description": "Python 基础第 31 课",
          "durationMs": 391000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-709d1e4d-5e7c-416a-b481-2377faea3545/parameterizedfunctions_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-709d1e4d-5e7c-416a-b481-2377faea3545/parameterizedfunctions_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-709d1e4d-5e7c-416a-b481-2377faea3545/parameterizedfunctions.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-31-of-44-parameterized-functions/",
          "publishDate": "2019-09-18T13:01:37Z",
          "captions": {
            "zh-cn": "captions/zh-cn/709d1e4d-5e7c-416a-b481-2377faea3545.vtt",
            "en-us": "captions/en-us/709d1e4d-5e7c-416a-b481-2377faea3545.vtt"
          }
        },
        {
          "id": "31c612d5-9ddd-4381-8e30-a7b12e5c1f6e",
          "track": "basics",
          "number": 32,
          "title": "Demo: Parameterized Functions",
          "rawTitle": "Python for Beginners [32 of 44] Demo: Parameterized Functions",
          "description": "Python 基础第 32 课",
          "durationMs": 280000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-31c612d5-9ddd-4381-8e30-a7b12e5c1f6e/demoparameterizedfunctions_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-31c612d5-9ddd-4381-8e30-a7b12e5c1f6e/demoparameterizedfunctions_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-31c612d5-9ddd-4381-8e30-a7b12e5c1f6e/demoparameterizedfunctions.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-32-of-44-demo-parameterized-functions/",
          "publishDate": "2019-09-18T13:01:39Z",
          "captions": {
            "zh-cn": "captions/zh-cn/31c612d5-9ddd-4381-8e30-a7b12e5c1f6e.vtt",
            "en-us": "captions/en-us/31c612d5-9ddd-4381-8e30-a7b12e5c1f6e.vtt"
          }
        },
        {
          "id": "9891db6b-17be-47af-bed9-d6cee563a4f5",
          "track": "basics",
          "number": 33,
          "title": "Modules and packages",
          "rawTitle": "Python for Beginners [33 of 44] Modules and packages",
          "description": "Python 基础第 33 课",
          "durationMs": 611000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-9891db6b-17be-47af-bed9-d6cee563a4f5/modulesandpackages_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-9891db6b-17be-47af-bed9-d6cee563a4f5/modulesandpackages_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-9891db6b-17be-47af-bed9-d6cee563a4f5/modulesandpackages.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-33-of-44-modules-and-packages/",
          "publishDate": "2019-09-19T12:58:06.022Z",
          "captions": {
            "zh-cn": "captions/zh-cn/9891db6b-17be-47af-bed9-d6cee563a4f5.vtt",
            "en-us": "captions/en-us/9891db6b-17be-47af-bed9-d6cee563a4f5.vtt"
          }
        },
        {
          "id": "5c00e3b5-3d58-43bd-9804-7091ffa0b24a",
          "track": "basics",
          "number": 34,
          "title": "Virtual Environments",
          "rawTitle": "Python for Beginners [34 of 44] Virtual Environments",
          "description": "Python 基础第 34 课",
          "durationMs": 355000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-5c00e3b5-3d58-43bd-9804-7091ffa0b24a/virtualenvironments_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-5c00e3b5-3d58-43bd-9804-7091ffa0b24a/virtualenvironments_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-5c00e3b5-3d58-43bd-9804-7091ffa0b24a/virtualenvironments.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-34-of-44-virtual-environments/",
          "publishDate": "2019-09-19T12:58:12.256Z",
          "captions": {
            "zh-cn": "captions/zh-cn/5c00e3b5-3d58-43bd-9804-7091ffa0b24a.vtt",
            "en-us": "captions/en-us/5c00e3b5-3d58-43bd-9804-7091ffa0b24a.vtt"
          }
        },
        {
          "id": "faa7a297-b258-4747-82fb-7d337747a7b2",
          "track": "basics",
          "number": 35,
          "title": "Demo: Virtual environments packages",
          "rawTitle": "Python for Beginners [35 of 44] Demo: Virtual environments packages",
          "description": "Python 基础第 35 课",
          "durationMs": 662000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-faa7a297-b258-4747-82fb-7d337747a7b2/demovirtualenvironmentspackages_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-faa7a297-b258-4747-82fb-7d337747a7b2/demovirtualenvironmentspackages_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-faa7a297-b258-4747-82fb-7d337747a7b2/demovirtualenvironmentspackages.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-35-of-44-demo-virtual-environments-packages/",
          "publishDate": "2019-09-19T12:58:17.466Z",
          "captions": {
            "zh-cn": "captions/zh-cn/faa7a297-b258-4747-82fb-7d337747a7b2.vtt",
            "en-us": "captions/en-us/faa7a297-b258-4747-82fb-7d337747a7b2.vtt"
          }
        },
        {
          "id": "cba02677-f416-4a4d-82d4-d0ef8b7b5d49",
          "track": "basics",
          "number": 36,
          "title": "Calling an API",
          "rawTitle": "Python for Beginners [36 of 44] Calling an API",
          "description": "Python 基础第 36 课",
          "durationMs": 612000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-cba02677-f416-4a4d-82d4-d0ef8b7b5d49/callinganapi_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-cba02677-f416-4a4d-82d4-d0ef8b7b5d49/callinganapi_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-cba02677-f416-4a4d-82d4-d0ef8b7b5d49/callinganapi.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-36-of-44-calling-an-api/",
          "publishDate": "2019-09-19T12:58:22.889Z",
          "captions": {
            "zh-cn": "captions/zh-cn/cba02677-f416-4a4d-82d4-d0ef8b7b5d49.vtt",
            "en-us": "captions/en-us/cba02677-f416-4a4d-82d4-d0ef8b7b5d49.vtt"
          }
        },
        {
          "id": "c60a0d28-7b07-4b15-9548-2c105c0a0a63",
          "track": "basics",
          "number": 37,
          "title": "Demo: Calling an API",
          "rawTitle": "Python for Beginners [37 of 44] Demo: Calling an API",
          "description": "Python 基础第 37 课",
          "durationMs": 648000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c60a0d28-7b07-4b15-9548-2c105c0a0a63/democallinganapi_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c60a0d28-7b07-4b15-9548-2c105c0a0a63/democallinganapi_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c60a0d28-7b07-4b15-9548-2c105c0a0a63/democallinganapi.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-37-of-44-demo-calling-an-api/",
          "publishDate": "2019-09-19T12:58:31.94Z",
          "captions": {
            "zh-cn": "captions/zh-cn/c60a0d28-7b07-4b15-9548-2c105c0a0a63.vtt",
            "en-us": "captions/en-us/c60a0d28-7b07-4b15-9548-2c105c0a0a63.vtt"
          }
        },
        {
          "id": "8a1b2472-2420-4fe6-ac29-85ae11e5823d",
          "track": "basics",
          "number": 38,
          "title": "JavaScript Object Notation (JSON)",
          "rawTitle": "Python for Beginners [38 of 44] JavaScript Object Notation (JSON)",
          "description": "Python 基础第 38 课",
          "durationMs": 645000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-8a1b2472-2420-4fe6-ac29-85ae11e5823d/json_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-8a1b2472-2420-4fe6-ac29-85ae11e5823d/json_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-8a1b2472-2420-4fe6-ac29-85ae11e5823d/json.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-38-of-44-javascript-object-notation-json/",
          "publishDate": "2019-09-19T12:58:39.368Z",
          "captions": {
            "zh-cn": "captions/zh-cn/8a1b2472-2420-4fe6-ac29-85ae11e5823d.vtt",
            "en-us": "captions/en-us/8a1b2472-2420-4fe6-ac29-85ae11e5823d.vtt"
          }
        },
        {
          "id": "acec927a-146c-45d5-b9c9-357d4c9ad609",
          "track": "basics",
          "number": 39,
          "title": "Demo: JSON",
          "rawTitle": "Python for Beginners [39 of 44] Demo: JSON",
          "description": "Python 基础第 39 课",
          "durationMs": 482000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-acec927a-146c-45d5-b9c9-357d4c9ad609/demojson_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-acec927a-146c-45d5-b9c9-357d4c9ad609/demojson_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-acec927a-146c-45d5-b9c9-357d4c9ad609/demojson.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-39-of-44-demo-json/",
          "publishDate": "2019-09-19T12:58:46.204Z",
          "captions": {
            "zh-cn": "captions/zh-cn/acec927a-146c-45d5-b9c9-357d4c9ad609.vtt",
            "en-us": "captions/en-us/acec927a-146c-45d5-b9c9-357d4c9ad609.vtt"
          }
        },
        {
          "id": "db0010fb-63fb-4de3-90a2-982d9bd6852e",
          "track": "basics",
          "number": 40,
          "title": "Managing keys",
          "rawTitle": "Python for Beginners [40 of 44] Managing keys",
          "description": "Python 基础第 40 课",
          "durationMs": 576000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-db0010fb-63fb-4de3-90a2-982d9bd6852e/managingkeys_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-db0010fb-63fb-4de3-90a2-982d9bd6852e/managingkeys_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-db0010fb-63fb-4de3-90a2-982d9bd6852e/managingkeys.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-40-of-44-managing-keys/",
          "publishDate": "2019-09-19T12:59:14.453Z",
          "captions": {
            "zh-cn": "captions/zh-cn/db0010fb-63fb-4de3-90a2-982d9bd6852e.vtt",
            "en-us": "captions/en-us/db0010fb-63fb-4de3-90a2-982d9bd6852e.vtt"
          }
        },
        {
          "id": "ddc22e59-62cd-40e9-ac61-cd72c8a4a43b",
          "track": "basics",
          "number": 41,
          "title": "Demo: Managing Keys",
          "rawTitle": "Python for Beginners [41 of 44] Demo: Managing Keys",
          "description": "Python 基础第 41 课",
          "durationMs": 379000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-ddc22e59-62cd-40e9-ac61-cd72c8a4a43b/demomanagingkeys_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-ddc22e59-62cd-40e9-ac61-cd72c8a4a43b/demomanagingkeys_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-ddc22e59-62cd-40e9-ac61-cd72c8a4a43b/demomanagingkeys.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-41-of-44-demo-managing-keys/",
          "publishDate": "2019-09-19T12:59:19.143Z",
          "captions": {
            "zh-cn": "captions/zh-cn/ddc22e59-62cd-40e9-ac61-cd72c8a4a43b.vtt",
            "en-us": "captions/en-us/ddc22e59-62cd-40e9-ac61-cd72c8a4a43b.vtt"
          }
        },
        {
          "id": "07c9f89b-9b41-4df9-aea8-13d9b97fc31d",
          "track": "basics",
          "number": 42,
          "title": "Decorators",
          "rawTitle": "Python for Beginners [42 of 44] Decorators",
          "description": "Python 基础第 42 课",
          "durationMs": 522000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-07c9f89b-9b41-4df9-aea8-13d9b97fc31d/decorators_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-07c9f89b-9b41-4df9-aea8-13d9b97fc31d/decorators_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-07c9f89b-9b41-4df9-aea8-13d9b97fc31d/decorators.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-42-of-44-decorators/",
          "publishDate": "2019-09-19T12:59:23.33Z",
          "captions": {
            "zh-cn": "captions/zh-cn/07c9f89b-9b41-4df9-aea8-13d9b97fc31d.vtt",
            "en-us": "captions/en-us/07c9f89b-9b41-4df9-aea8-13d9b97fc31d.vtt"
          }
        },
        {
          "id": "f5fa7c77-b233-4115-a7ab-20892fe6fe1c",
          "track": "basics",
          "number": 43,
          "title": "Demo: Decorators",
          "rawTitle": "Python for Beginners [43 of 44] Demo: Decorators",
          "description": "Python 基础第 43 课",
          "durationMs": 138000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f5fa7c77-b233-4115-a7ab-20892fe6fe1c/demodecorators_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f5fa7c77-b233-4115-a7ab-20892fe6fe1c/demodecorators_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f5fa7c77-b233-4115-a7ab-20892fe6fe1c/demodecorators.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-43-of-44-demo-decorators/",
          "publishDate": "2019-09-19T12:59:27.495Z",
          "captions": {
            "zh-cn": "captions/zh-cn/f5fa7c77-b233-4115-a7ab-20892fe6fe1c.vtt",
            "en-us": "captions/en-us/f5fa7c77-b233-4115-a7ab-20892fe6fe1c.vtt"
          }
        },
        {
          "id": "0fda87c4-e8d7-468e-ad7d-81e4707dea05",
          "track": "basics",
          "number": 44,
          "title": "Next steps",
          "rawTitle": "Python for Beginners [44 of 44] Next steps",
          "description": "Python 基础第 44 课",
          "durationMs": 302000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-0fda87c4-e8d7-468e-ad7d-81e4707dea05/nextsteps_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-0fda87c4-e8d7-468e-ad7d-81e4707dea05/nextsteps_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-0fda87c4-e8d7-468e-ad7d-81e4707dea05/nextsteps.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/intro-to-python-development/python-for-beginners-44-of-44-next-steps/",
          "publishDate": "2019-09-19T12:59:32.729Z",
          "captions": {
            "zh-cn": "captions/zh-cn/0fda87c4-e8d7-468e-ad7d-81e4707dea05.vtt",
            "en-us": "captions/en-us/0fda87c4-e8d7-468e-ad7d-81e4707dea05.vtt"
          }
        }
      ]
    },
    {
      "id": "more",
      "showUid": "more-python-for-beginners",
      "title": "More Python for Beginners",
      "shortTitle": "Python 进阶",
      "description": "继续学习 Lambda、类、继承、Mixin、文件系统、资源管理和异步编程。",
      "sourceUrl": "https://learn.microsoft.com/en-us/shows/more-python-for-beginners/",
      "repoUrl": "../more-python-for-beginners/README.md",
      "accent": "teal",
      "lessonCount": 20,
      "videoCount": 20,
      "durationMs": 8615000,
      "lessons": [
        {
          "id": "db8d607e-9b33-4ba4-a8ff-86158a9923f3",
          "track": "more",
          "number": 1,
          "title": "Introducing More Python for Beginners",
          "rawTitle": "Introducing More Python for Beginners |  More Python for Beginners [1 of 20]",
          "description": "Python 进阶第 1 课",
          "durationMs": 204000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-db8d607e-9b33-4ba4-a8ff-86158a9923f3/s1video01-678_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-db8d607e-9b33-4ba4-a8ff-86158a9923f3/s1video01-678_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-db8d607e-9b33-4ba4-a8ff-86158a9923f3/s1video01-678.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/introducing-more-python-for-beginners--more-python-for-beginners-1-of-20/",
          "publishDate": "2020-04-28T19:30:00Z",
          "captions": {
            "zh-cn": "captions/zh-cn/db8d607e-9b33-4ba4-a8ff-86158a9923f3.vtt",
            "en-us": "captions/en-us/db8d607e-9b33-4ba4-a8ff-86158a9923f3.vtt"
          }
        },
        {
          "id": "036f3244-4e01-4b12-ab69-fb243e75c15e",
          "track": "more",
          "number": 2,
          "title": "Formatting and Linting",
          "rawTitle": "Formatting and Linting |  More Python for Beginners [2 of 20]",
          "description": "Python 进阶第 2 课",
          "durationMs": 630000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-036f3244-4e01-4b12-ab69-fb243e75c15e/s1video02-659formattingandlinting_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-036f3244-4e01-4b12-ab69-fb243e75c15e/s1video02-659formattingandlinting_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-036f3244-4e01-4b12-ab69-fb243e75c15e/s1video02-659formattingandlinting.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/formatting-and-linting--more-python-for-beginners-2-of-20/",
          "publishDate": "2020-04-28T19:30:01Z",
          "captions": {
            "zh-cn": "captions/zh-cn/036f3244-4e01-4b12-ab69-fb243e75c15e.vtt",
            "en-us": "captions/en-us/036f3244-4e01-4b12-ab69-fb243e75c15e.vtt"
          }
        },
        {
          "id": "8142ddd8-ee61-40c7-ac99-e3c57c767588",
          "track": "more",
          "number": 3,
          "title": "Demo: Formatting and Linting",
          "rawTitle": "Demo: Formatting and Linting |  More Python for Beginners [3 of 20]",
          "description": "Python 进阶第 3 课",
          "durationMs": 424000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-8142ddd8-ee61-40c7-ac99-e3c57c767588/s1video03-660formattingandlintingdemo_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-8142ddd8-ee61-40c7-ac99-e3c57c767588/s1video03-660formattingandlintingdemo_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-8142ddd8-ee61-40c7-ac99-e3c57c767588/s1video03-660formattingandlintingdemo.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/demo-formatting-and-linting--more-python-for-beginners-3-of-20/",
          "publishDate": "2020-04-28T19:30:02Z",
          "captions": {
            "zh-cn": "captions/zh-cn/8142ddd8-ee61-40c7-ac99-e3c57c767588.vtt",
            "en-us": "captions/en-us/8142ddd8-ee61-40c7-ac99-e3c57c767588.vtt"
          }
        },
        {
          "id": "006dbc6c-732f-47a3-b608-fbb47881035f",
          "track": "more",
          "number": 4,
          "title": "Lambdas",
          "rawTitle": "Lambdas | More Python for Beginners [4 of 20]",
          "description": "Python 进阶第 4 课",
          "durationMs": 269000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-006dbc6c-732f-47a3-b608-fbb47881035f/s1video04-661lambdas_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-006dbc6c-732f-47a3-b608-fbb47881035f/s1video04-661lambdas_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-006dbc6c-732f-47a3-b608-fbb47881035f/s1video04-661lambdas.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/lambdas--more-python-for-beginners-4-of-20/",
          "publishDate": "2020-04-28T19:30:03Z",
          "captions": {
            "zh-cn": "captions/zh-cn/006dbc6c-732f-47a3-b608-fbb47881035f.vtt",
            "en-us": "captions/en-us/006dbc6c-732f-47a3-b608-fbb47881035f.vtt"
          }
        },
        {
          "id": "884cdc6f-9ce3-42db-b7c7-73cf9c16a48a",
          "track": "more",
          "number": 5,
          "title": "Demo: Lambdas",
          "rawTitle": "Demo: Lambdas | More Python for Beginners [5 of 20]",
          "description": "Python 进阶第 5 课",
          "durationMs": 242000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-884cdc6f-9ce3-42db-b7c7-73cf9c16a48a/s1video05-662lambdasdemo_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-884cdc6f-9ce3-42db-b7c7-73cf9c16a48a/s1video05-662lambdasdemo_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-884cdc6f-9ce3-42db-b7c7-73cf9c16a48a/s1video05-662lambdasdemo.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/demo-lambdas--more-python-for-beginners-5-of-20/",
          "publishDate": "2020-04-28T19:30:04Z",
          "captions": {
            "zh-cn": "captions/zh-cn/884cdc6f-9ce3-42db-b7c7-73cf9c16a48a.vtt",
            "en-us": "captions/en-us/884cdc6f-9ce3-42db-b7c7-73cf9c16a48a.vtt"
          }
        },
        {
          "id": "cc283424-2d28-4042-ba6c-ca24f94b0b5e",
          "track": "more",
          "number": 6,
          "title": "Classes",
          "rawTitle": "Classes | More Python for Beginners [6 of 20]",
          "description": "Python 进阶第 6 课",
          "durationMs": 715000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-cc283424-2d28-4042-ba6c-ca24f94b0b5e/s1video06-663classes_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-cc283424-2d28-4042-ba6c-ca24f94b0b5e/s1video06-663classes_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-cc283424-2d28-4042-ba6c-ca24f94b0b5e/s1video06-663classes.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/classes--more-python-for-beginners-6-of-20/",
          "publishDate": "2020-04-28T19:30:05Z",
          "captions": {
            "zh-cn": "captions/zh-cn/cc283424-2d28-4042-ba6c-ca24f94b0b5e.vtt",
            "en-us": "captions/en-us/cc283424-2d28-4042-ba6c-ca24f94b0b5e.vtt"
          }
        },
        {
          "id": "d321ac31-40ee-4e4e-8f02-3ba8ddedf3d1",
          "track": "more",
          "number": 7,
          "title": "Demo: Classes",
          "rawTitle": "Demo: Classes | More Python for Beginners [7 of 20]",
          "description": "Python 进阶第 7 课",
          "durationMs": 436000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-d321ac31-40ee-4e4e-8f02-3ba8ddedf3d1/s1video07-664classesdemo_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-d321ac31-40ee-4e4e-8f02-3ba8ddedf3d1/s1video07-664classesdemo_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-d321ac31-40ee-4e4e-8f02-3ba8ddedf3d1/s1video07-664classesdemo.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/demo-classes--more-python-for-beginners-7-of-20/",
          "publishDate": "2020-04-28T19:30:06Z",
          "captions": {
            "zh-cn": "captions/zh-cn/d321ac31-40ee-4e4e-8f02-3ba8ddedf3d1.vtt",
            "en-us": "captions/en-us/d321ac31-40ee-4e4e-8f02-3ba8ddedf3d1.vtt"
          }
        },
        {
          "id": "ca3d3b59-ddd1-4502-a068-8e09a1b6efc7",
          "track": "more",
          "number": 8,
          "title": "Inheritance",
          "rawTitle": "Inheritance | More Python for Beginners [8 of 20]",
          "description": "Python 进阶第 8 课",
          "durationMs": 596000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-ca3d3b59-ddd1-4502-a068-8e09a1b6efc7/s1video08-665inheritance_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-ca3d3b59-ddd1-4502-a068-8e09a1b6efc7/s1video08-665inheritance_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-ca3d3b59-ddd1-4502-a068-8e09a1b6efc7/s1video08-665inheritance.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/inheritance--more-python-for-beginners-8-of-20/",
          "publishDate": "2020-04-28T19:30:07Z",
          "captions": {
            "zh-cn": "captions/zh-cn/ca3d3b59-ddd1-4502-a068-8e09a1b6efc7.vtt",
            "en-us": "captions/en-us/ca3d3b59-ddd1-4502-a068-8e09a1b6efc7.vtt"
          }
        },
        {
          "id": "6dbe566b-e8e6-4795-9871-b00b4e68fd5f",
          "track": "more",
          "number": 9,
          "title": "Demo: Inheritance",
          "rawTitle": "Demo: Inheritance | More Python for Beginners [9 of 20]",
          "description": "Python 进阶第 9 课",
          "durationMs": 663000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-6dbe566b-e8e6-4795-9871-b00b4e68fd5f/s1video09-666inheritancedemo_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-6dbe566b-e8e6-4795-9871-b00b4e68fd5f/s1video09-666inheritancedemo_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-6dbe566b-e8e6-4795-9871-b00b4e68fd5f/s1video09-666inheritancedemo.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/demo-inheritance--more-python-for-beginners-9-of-20/",
          "publishDate": "2020-04-28T19:30:08Z",
          "captions": {
            "zh-cn": "captions/zh-cn/6dbe566b-e8e6-4795-9871-b00b4e68fd5f.vtt",
            "en-us": "captions/en-us/6dbe566b-e8e6-4795-9871-b00b4e68fd5f.vtt"
          }
        },
        {
          "id": "f080fbe9-d68b-421c-8766-5fd22d470589",
          "track": "more",
          "number": 10,
          "title": "Mixins (Multiple inheritance)",
          "rawTitle": "Mixins (Multiple inheritance) | More Python for Beginners [10 of 20]",
          "description": "Python 进阶第 10 课",
          "durationMs": 652000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f080fbe9-d68b-421c-8766-5fd22d470589/s1video10-667mixins_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f080fbe9-d68b-421c-8766-5fd22d470589/s1video10-667mixins_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f080fbe9-d68b-421c-8766-5fd22d470589/s1video10-667mixins.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/mixins-multiple-inheritance--more-python-for-beginners-10-of-20/",
          "publishDate": "2020-04-28T19:30:09Z",
          "captions": {
            "zh-cn": "captions/zh-cn/f080fbe9-d68b-421c-8766-5fd22d470589.vtt",
            "en-us": "captions/en-us/f080fbe9-d68b-421c-8766-5fd22d470589.vtt"
          }
        },
        {
          "id": "f3f35360-5cda-4eca-a825-53bc4214a0e0",
          "track": "more",
          "number": 11,
          "title": "Demo: Mixins",
          "rawTitle": "Demo: Mixins | More Python for Beginners [11 of 20]",
          "description": "Python 进阶第 11 课",
          "durationMs": 280000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f3f35360-5cda-4eca-a825-53bc4214a0e0/s1video11-668mixinsdemo_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f3f35360-5cda-4eca-a825-53bc4214a0e0/s1video11-668mixinsdemo_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f3f35360-5cda-4eca-a825-53bc4214a0e0/s1video11-668mixinsdemo.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/demo-mixins--more-python-for-beginners-11-of-20/",
          "publishDate": "2020-04-28T19:30:10Z",
          "captions": {
            "zh-cn": "captions/zh-cn/f3f35360-5cda-4eca-a825-53bc4214a0e0.vtt",
            "en-us": "captions/en-us/f3f35360-5cda-4eca-a825-53bc4214a0e0.vtt"
          }
        },
        {
          "id": "29f2c899-2633-47db-802e-a790f956bd9a",
          "track": "more",
          "number": 12,
          "title": "Managing the file system",
          "rawTitle": "Managing the file system | More Python for Beginners [12 of 20]",
          "description": "Python 进阶第 12 课",
          "durationMs": 272000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-29f2c899-2633-47db-802e-a790f956bd9a/s1video12-669managingthefilesystem_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-29f2c899-2633-47db-802e-a790f956bd9a/s1video12-669managingthefilesystem_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-29f2c899-2633-47db-802e-a790f956bd9a/s1video12-669managingthefilesystem.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/managing-the-file-system--more-python-for-beginners-12-of-20/",
          "publishDate": "2020-04-28T19:30:11Z",
          "captions": {
            "zh-cn": "captions/zh-cn/29f2c899-2633-47db-802e-a790f956bd9a.vtt",
            "en-us": "captions/en-us/29f2c899-2633-47db-802e-a790f956bd9a.vtt"
          }
        },
        {
          "id": "986b98d8-2e69-4850-90a0-ce634a3612e4",
          "track": "more",
          "number": 13,
          "title": "Demo: Managing the file system",
          "rawTitle": "Demo: Managing the file system | More Python for Beginners [13 of 20]",
          "description": "Python 进阶第 13 课",
          "durationMs": 434000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-986b98d8-2e69-4850-90a0-ce634a3612e4/s1video13-670managingthefilesystemdemo_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-986b98d8-2e69-4850-90a0-ce634a3612e4/s1video13-670managingthefilesystemdemo_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-986b98d8-2e69-4850-90a0-ce634a3612e4/s1video13-670managingthefilesystemdemo.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/demo-managing-the-file-system--more-python-for-beginners-13-of-20/",
          "publishDate": "2020-04-28T19:30:12Z",
          "captions": {
            "zh-cn": "captions/zh-cn/986b98d8-2e69-4850-90a0-ce634a3612e4.vtt",
            "en-us": "captions/en-us/986b98d8-2e69-4850-90a0-ce634a3612e4.vtt"
          }
        },
        {
          "id": "f9820cfb-a4fe-4760-aeff-5bf546a1a86f",
          "track": "more",
          "number": 14,
          "title": "Working with files",
          "rawTitle": "Working with files | More Python for Beginners [14 of 20]",
          "description": "Python 进阶第 14 课",
          "durationMs": 474000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f9820cfb-a4fe-4760-aeff-5bf546a1a86f/s1video14-671workingwithfiles_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f9820cfb-a4fe-4760-aeff-5bf546a1a86f/s1video14-671workingwithfiles_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f9820cfb-a4fe-4760-aeff-5bf546a1a86f/s1video14-671workingwithfiles.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/working-with-files--more-python-for-beginners-14-of-20/",
          "publishDate": "2020-04-28T19:30:13Z",
          "captions": {
            "zh-cn": "captions/zh-cn/f9820cfb-a4fe-4760-aeff-5bf546a1a86f.vtt",
            "en-us": "captions/en-us/f9820cfb-a4fe-4760-aeff-5bf546a1a86f.vtt"
          }
        },
        {
          "id": "dded8c61-aee4-4261-add2-be78106db434",
          "track": "more",
          "number": 15,
          "title": "Demo: Working with files",
          "rawTitle": "Demo: Working with files | More Python for Beginners [15 of 20]",
          "description": "Python 进阶第 15 课",
          "durationMs": 418000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-dded8c61-aee4-4261-add2-be78106db434/s1video15-672workingwithfilesdemo_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-dded8c61-aee4-4261-add2-be78106db434/s1video15-672workingwithfilesdemo_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-dded8c61-aee4-4261-add2-be78106db434/s1video15-672workingwithfilesdemo.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/demo-working-with-files--more-python-for-beginners-15-of-20/",
          "publishDate": "2020-04-28T19:30:14Z",
          "captions": {
            "zh-cn": "captions/zh-cn/dded8c61-aee4-4261-add2-be78106db434.vtt",
            "en-us": "captions/en-us/dded8c61-aee4-4261-add2-be78106db434.vtt"
          }
        },
        {
          "id": "c07ca89b-1f32-4081-9a1c-1a427cb23bcf",
          "track": "more",
          "number": 16,
          "title": "Using with to automatically close resources",
          "rawTitle": "Using with to automatically close resources |  More Python for Beginners [16 of 20]",
          "description": "Python 进阶第 16 课",
          "durationMs": 138000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c07ca89b-1f32-4081-9a1c-1a427cb23bcf/s1video16-673cleanupwithwith_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c07ca89b-1f32-4081-9a1c-1a427cb23bcf/s1video16-673cleanupwithwith_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-c07ca89b-1f32-4081-9a1c-1a427cb23bcf/s1video16-673cleanupwithwith.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/using-with-to-automatically-close-resources--more-python-for-beginners-16-of-20/",
          "publishDate": "2020-04-28T19:30:15Z",
          "captions": {
            "zh-cn": "captions/zh-cn/c07ca89b-1f32-4081-9a1c-1a427cb23bcf.vtt",
            "en-us": "captions/en-us/c07ca89b-1f32-4081-9a1c-1a427cb23bcf.vtt"
          }
        },
        {
          "id": "95f1637a-0d60-4093-9ab2-fc83e5507bd1",
          "track": "more",
          "number": 17,
          "title": "Demo: Using with",
          "rawTitle": "Demo: Using with | More Python for Beginners [17 of 20]",
          "description": "Python 进阶第 17 课",
          "durationMs": 123000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-95f1637a-0d60-4093-9ab2-fc83e5507bd1/s1video17-674cleanupwithwithdemo_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-95f1637a-0d60-4093-9ab2-fc83e5507bd1/s1video17-674cleanupwithwithdemo_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-95f1637a-0d60-4093-9ab2-fc83e5507bd1/s1video17-674cleanupwithwithdemo.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/demo-using-with--more-python-for-beginners-17-of-20/",
          "publishDate": "2020-04-28T19:30:16Z",
          "captions": {
            "zh-cn": "captions/zh-cn/95f1637a-0d60-4093-9ab2-fc83e5507bd1.vtt",
            "en-us": "captions/en-us/95f1637a-0d60-4093-9ab2-fc83e5507bd1.vtt"
          }
        },
        {
          "id": "f8d32a11-bcda-4259-945a-12b18b5c3396",
          "track": "more",
          "number": 18,
          "title": "Asynchronous operations",
          "rawTitle": "Asynchronous operations | More Python for Beginners [18 of 20]",
          "description": "Python 进阶第 18 课",
          "durationMs": 750000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f8d32a11-bcda-4259-945a-12b18b5c3396/s1video18-675asynchronousoperations_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f8d32a11-bcda-4259-945a-12b18b5c3396/s1video18-675asynchronousoperations_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-f8d32a11-bcda-4259-945a-12b18b5c3396/s1video18-675asynchronousoperations.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/asynchronous-operations--more-python-for-beginners-18-of-20/",
          "publishDate": "2020-04-28T19:30:17Z",
          "captions": {
            "zh-cn": "captions/zh-cn/f8d32a11-bcda-4259-945a-12b18b5c3396.vtt",
            "en-us": "captions/en-us/f8d32a11-bcda-4259-945a-12b18b5c3396.vtt"
          }
        },
        {
          "id": "014c202c-9399-4321-8a39-b2f08de6cd0e",
          "track": "more",
          "number": 19,
          "title": "Demo: Asynchronous operations",
          "rawTitle": "Demo: Asynchronous operations | More Python for Beginners [19 of 20]",
          "description": "Python 进阶第 19 课",
          "durationMs": 821000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-014c202c-9399-4321-8a39-b2f08de6cd0e/s1video19-677asynchronousoperationsdemo_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-014c202c-9399-4321-8a39-b2f08de6cd0e/s1video19-677asynchronousoperationsdemo_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-014c202c-9399-4321-8a39-b2f08de6cd0e/s1video19-677asynchronousoperationsdemo.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/demo-asynchronous-operations--more-python-for-beginners-19-of-20/",
          "publishDate": "2020-04-28T19:30:18Z",
          "captions": {
            "zh-cn": "captions/zh-cn/014c202c-9399-4321-8a39-b2f08de6cd0e.vtt",
            "en-us": "captions/en-us/014c202c-9399-4321-8a39-b2f08de6cd0e.vtt"
          }
        },
        {
          "id": "888faa79-fadc-42ee-8825-0aab82f8f9f2",
          "track": "more",
          "number": 20,
          "title": "Closing",
          "rawTitle": "Closing | More Python for Beginners [20 of 20}",
          "description": "Python 进阶第 20 课",
          "durationMs": 74000,
          "thumbnail": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-888faa79-fadc-42ee-8825-0aab82f8f9f2/s1video20-678outro_960.jpg",
          "videoUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-888faa79-fadc-42ee-8825-0aab82f8f9f2/s1video20-678outro_mid.mp4",
          "audioUrl": "https://videoencodingpublic-hgeaeyeba8gycee3.b01.azurefd.net/public-888faa79-fadc-42ee-8825-0aab82f8f9f2/s1video20-678outro.mp3",
          "pageUrl": "https://learn.microsoft.com/shows/more-python-for-beginners/closing--more-python-for-beginners-20-of-20/",
          "publishDate": "2020-04-28T19:30:19Z",
          "captions": {
            "zh-cn": "captions/zh-cn/888faa79-fadc-42ee-8825-0aab82f8f9f2.vtt",
            "en-us": "captions/en-us/888faa79-fadc-42ee-8825-0aab82f8f9f2.vtt"
          }
        }
      ]
    },
    {
      "id": "data",
      "title": "Even More Python for Beginners: Data Tools",
      "shortTitle": "数据工具",
      "description": "通过 15 个本地 Notebook 练习 Jupyter、Pandas、scikit-learn、NumPy 与 Matplotlib。",
      "sourceUrl": "../even-more-python-for-beginners-data-tools/README.md",
      "repoUrl": "../even-more-python-for-beginners-data-tools/README.md",
      "accent": "amber",
      "lessons": [
        {
          "number": 1,
          "title": "Jupyter Notebooks",
          "description": "了解 Jupyter Notebook 的单元格、执行方式和课程练习流程。",
          "href": "../even-more-python-for-beginners-data-tools/01 - Jupyter Notebooks/README.md",
          "type": "guide"
        },
        {
          "number": 2,
          "title": "Anaconda and Conda",
          "description": "理解 Python 环境、Conda 环境与包管理的基本概念。",
          "href": "../even-more-python-for-beginners-data-tools/02 - Introduction to Anaconda and Conda/README.md",
          "type": "guide"
        },
        {
          "number": 3,
          "title": "Pandas Series and DataFrame",
          "description": "创建并理解 Pandas 最常用的两个数据结构。",
          "href": "../even-more-python-for-beginners-data-tools/03 - Intro to Pandas/03 - Pandas Series and DataFrame.ipynb",
          "type": "notebook"
        },
        {
          "number": 4,
          "title": "Examining DataFrame Contents",
          "description": "使用 head、tail、info、describe 等方法检查数据。",
          "href": "../even-more-python-for-beginners-data-tools/04 - Examining Pandas DataFrame contents/04 - Exploring pandas DataFrame contents.ipynb",
          "type": "notebook"
        },
        {
          "number": 5,
          "title": "Querying DataFrames",
          "description": "按条件、列和索引筛选 DataFrame 中的数据。",
          "href": "../even-more-python-for-beginners-data-tools/05 - Query a pandas Dataframe/05 - Querying DataFrames.ipynb",
          "type": "notebook"
        },
        {
          "number": 6,
          "title": "CSV Files and Notebooks",
          "description": "在 Jupyter Notebook 中读取并查看 CSV 文件。",
          "href": "../even-more-python-for-beginners-data-tools/06 - CSV Files and Jupyter Notebooks/README.md",
          "type": "guide"
        },
        {
          "number": 7,
          "title": "Read and Write CSV Files",
          "description": "使用 Pandas DataFrame 完成 CSV 数据读写。",
          "href": "../even-more-python-for-beginners-data-tools/07 - Read and write CSV files from pandas DataFrames/07 - Read write CSV files.ipynb",
          "type": "notebook"
        },
        {
          "number": 8,
          "title": "Remove and Split Columns",
          "description": "删除不需要的字段，并将一列拆分为多个字段。",
          "href": "../even-more-python-for-beginners-data-tools/08 - Removing and splitting DataFrame columns/08 - Removing columns.ipynb",
          "type": "notebook"
        },
        {
          "number": 9,
          "title": "Duplicates and Missing Values",
          "description": "定位并处理重复行和缺失数据。",
          "href": "../even-more-python-for-beginners-data-tools/09 - Handling duplicates and rows with missing values/09 - Removing rows.ipynb",
          "type": "notebook"
        },
        {
          "number": 10,
          "title": "Train Test Split",
          "description": "使用 scikit-learn 划分训练集和测试集。",
          "href": "../even-more-python-for-beginners-data-tools/10 - Splitting test and training data with scikit-learn/10 - Train Test split.ipynb",
          "type": "notebook"
        },
        {
          "number": 11,
          "title": "Train a Basic Model",
          "description": "训练第一个线性回归模型。",
          "href": "../even-more-python-for-beginners-data-tools/11 - Train a linear regression model with scikit-learn/11 - Train a basic model.ipynb",
          "type": "notebook"
        },
        {
          "number": 12,
          "title": "Testing a Model",
          "description": "使用测试集检查模型预测结果。",
          "href": "../even-more-python-for-beginners-data-tools/12 - Testing a model/12 - Test a model.ipynb",
          "type": "notebook"
        },
        {
          "number": 13,
          "title": "Evaluate Accuracy",
          "description": "通过计算结果评估模型准确率。",
          "href": "../even-more-python-for-beginners-data-tools/13 - Evaluating accuracy of a model using calculations/13 - Evaluate accuracy.ipynb",
          "type": "notebook"
        },
        {
          "number": 14,
          "title": "NumPy and Pandas",
          "description": "比较数组计算和表格数据处理。",
          "href": "../even-more-python-for-beginners-data-tools/14 - NumPy vs Pandas/14 - Working with numpy and pandas.ipynb",
          "type": "notebook"
        },
        {
          "number": 15,
          "title": "Visualizing Data",
          "description": "使用 Matplotlib 观察变量之间的关系。",
          "href": "../even-more-python-for-beginners-data-tools/15 - Visualizing data with Matplotlib/15 - Visualizing correlations.ipynb",
          "type": "notebook"
        }
      ],
      "lessonCount": 15,
      "videoCount": 0,
      "durationMs": 0
    }
  ],
  "assignments": {
    "exerciseCount": 10,
    "fileCount": 19,
    "solutionCount": 9,
    "groups": [
      {
        "id": "2-print",
        "lessonNumber": 2,
        "title": "Print",
        "description": "修复打印语句中的引号、函数拼写和括号错误。",
        "taskFile": {
          "name": "coding_challenge.py",
          "role": "task",
          "label": "题目代码",
          "code": "# Here's a challenge for you to help you practice\n# See if you can fix the code below \n\n# print the message\nprint('Why won't this line of code print')\n\n# print the message\nprnit('This line fails too!')\n\n# print the message\nprint \"I think I know how to fix this one\"\n\n# print the name entered by the user\ninput('Please tell me your name: ')\nprint(name)\n",
          "href": "../python-for-beginners/02%20-%20Print/coding_challenge.py"
        },
        "solutionFile": {
          "name": "coding_challenge_solution.py",
          "role": "solution",
          "label": "参考答案",
          "code": "# Here's a challenge for you to help you practice\n# See if you can fix the code below \n\n# print the message\n# There was a single quote inside the string!\n# Use double quotes to enclose the string\nprint(\"Why won't this line of code print\")\n\n# print the message\n# There was a mistake in the function name\nprint('This line fails too!')\n\n# print the message\n# Need to add the () around the string\nprint (\"I think I know how to fix this one\")\n\n# print the name entered by the user\n# You need to store the value returned by the input statement\n# in a variable\nname = input('Please tell me your name: ')\nprint(name)\n",
          "href": "../python-for-beginners/02%20-%20Print/coding_challenge_solution.py"
        },
        "files": [
          {
            "name": "coding_challenge_solution.py",
            "role": "solution",
            "label": "参考答案",
            "code": "# Here's a challenge for you to help you practice\n# See if you can fix the code below \n\n# print the message\n# There was a single quote inside the string!\n# Use double quotes to enclose the string\nprint(\"Why won't this line of code print\")\n\n# print the message\n# There was a mistake in the function name\nprint('This line fails too!')\n\n# print the message\n# Need to add the () around the string\nprint (\"I think I know how to fix this one\")\n\n# print the name entered by the user\n# You need to store the value returned by the input statement\n# in a variable\nname = input('Please tell me your name: ')\nprint(name)\n",
            "href": "../python-for-beginners/02%20-%20Print/coding_challenge_solution.py"
          },
          {
            "name": "coding_challenge.py",
            "role": "task",
            "label": "题目代码",
            "code": "# Here's a challenge for you to help you practice\n# See if you can fix the code below \n\n# print the message\nprint('Why won't this line of code print')\n\n# print the message\nprnit('This line fails too!')\n\n# print the message\nprint \"I think I know how to fix this one\"\n\n# print the name entered by the user\ninput('Please tell me your name: ')\nprint(name)\n",
            "href": "../python-for-beginners/02%20-%20Print/coding_challenge.py"
          }
        ],
        "fileCount": 2,
        "preview": "# Here's a challenge for you to help you practice\n# See if you can fix the code below \n\n# print the message\nprint('Why won't this line of code print')\n\n# print the message\nprnit('This line fails too!')\n\n# print the message\nprint \"I think I know how to fix this one\"\n"
      },
      {
        "id": "4-string-variables",
        "lessonNumber": 4,
        "title": "String variables",
        "description": "读取姓名并输出首字母大写、其余字母小写的完整姓名。",
        "taskFile": {
          "name": "code_challenge.py",
          "role": "task",
          "label": "题目代码",
          "code": "# ask a user to enter their first name and store it in a variable\n# ask a user to enter their last name and store it in a variable\n# print their full name\n# Make sure you have a space between first and last name\n# Make sure the first letter of first name and last name is uppercase\n# Make sure the rest of the name is lowercase\n",
          "href": "../python-for-beginners/04%20-%20String%20variables/code_challenge.py"
        },
        "solutionFile": {
          "name": "code_challenge_solution.py",
          "role": "solution",
          "label": "参考答案",
          "code": "# ask a user to enter their first name and store it in a variable\nfirst_name = input('What is your first name? ')\n# ask a user to enter their last name and store it in a variable\nlast_name = input('What is your last name? ')\n\n# print their full name\n# Make sure you have a space between first and last name\n# Make sure the first letter of first name and last name is uppercase\n# Make sure the rest of the name is lowercase\nprint(first_name.capitalize() + ' ' + last_name.capitalize())",
          "href": "../python-for-beginners/04%20-%20String%20variables/code_challenge_solution.py"
        },
        "files": [
          {
            "name": "code_challenge_solution.py",
            "role": "solution",
            "label": "参考答案",
            "code": "# ask a user to enter their first name and store it in a variable\nfirst_name = input('What is your first name? ')\n# ask a user to enter their last name and store it in a variable\nlast_name = input('What is your last name? ')\n\n# print their full name\n# Make sure you have a space between first and last name\n# Make sure the first letter of first name and last name is uppercase\n# Make sure the rest of the name is lowercase\nprint(first_name.capitalize() + ' ' + last_name.capitalize())",
            "href": "../python-for-beginners/04%20-%20String%20variables/code_challenge_solution.py"
          },
          {
            "name": "code_challenge.py",
            "role": "task",
            "label": "题目代码",
            "code": "# ask a user to enter their first name and store it in a variable\n# ask a user to enter their last name and store it in a variable\n# print their full name\n# Make sure you have a space between first and last name\n# Make sure the first letter of first name and last name is uppercase\n# Make sure the rest of the name is lowercase\n",
            "href": "../python-for-beginners/04%20-%20String%20variables/code_challenge.py"
          }
        ],
        "fileCount": 2,
        "preview": "# ask a user to enter their first name and store it in a variable\n# ask a user to enter their last name and store it in a variable\n# print their full name\n# Make sure you have a space between first and last name\n# Make sure the first letter of first name and last name is uppercase\n# Make sure the rest of the name is lowercase\n"
      },
      {
        "id": "5-numeric-variables",
        "lessonNumber": 5,
        "title": "Numeric variables",
        "description": "读取两个数字，完成数值转换、求和和格式化输出。",
        "taskFile": {
          "name": "code_challenge.py",
          "role": "task",
          "label": "题目代码",
          "code": "# Ask a user to enter a number\n# Ask a user to enter a second number\n# Calculate the total of the two numbers added together\n# Print 'first number + second number = answer' \n# For example if someone enters 4 and 6 the output should read\n# 4 + 6 = 10\n",
          "href": "../python-for-beginners/05%20-%20Numeric%20variables/code_challenge.py"
        },
        "solutionFile": {
          "name": "code_challenge_solution.py",
          "role": "solution",
          "label": "参考答案",
          "code": "# Ask a user to enter a number\nfirst_number = input('Enter a number: ')\n\n# Ask a user to enter a second number\nsecond_number = input('Enter another number: ')\n\n# Calculate the total of the two numbers added together\nanswer = float(first_number) + float(second_number)\n\n# Print 'first number + second number = answer' \n# For example if someone enters 4 and 6 the output should read\n# 4 + 6 = 10\nprint(first_number + ' + ' + second_number + ' = ' + str(answer))\n\n# If you do not want the decimal places you could round the answer\nprint(first_number + ' + ' + second_number + ' = ' + str(round(answer)))",
          "href": "../python-for-beginners/05%20-%20Numeric%20variables/code_challenge_solution.py"
        },
        "files": [
          {
            "name": "code_challenge_solution.py",
            "role": "solution",
            "label": "参考答案",
            "code": "# Ask a user to enter a number\nfirst_number = input('Enter a number: ')\n\n# Ask a user to enter a second number\nsecond_number = input('Enter another number: ')\n\n# Calculate the total of the two numbers added together\nanswer = float(first_number) + float(second_number)\n\n# Print 'first number + second number = answer' \n# For example if someone enters 4 and 6 the output should read\n# 4 + 6 = 10\nprint(first_number + ' + ' + second_number + ' = ' + str(answer))\n\n# If you do not want the decimal places you could round the answer\nprint(first_number + ' + ' + second_number + ' = ' + str(round(answer)))",
            "href": "../python-for-beginners/05%20-%20Numeric%20variables/code_challenge_solution.py"
          },
          {
            "name": "code_challenge.py",
            "role": "task",
            "label": "题目代码",
            "code": "# Ask a user to enter a number\n# Ask a user to enter a second number\n# Calculate the total of the two numbers added together\n# Print 'first number + second number = answer' \n# For example if someone enters 4 and 6 the output should read\n# 4 + 6 = 10\n",
            "href": "../python-for-beginners/05%20-%20Numeric%20variables/code_challenge.py"
          }
        ],
        "fileCount": 2,
        "preview": "# Ask a user to enter a number\n# Ask a user to enter a second number\n# Calculate the total of the two numbers added together\n# Print 'first number + second number = answer' \n# For example if someone enters 4 and 6 the output should read\n# 4 + 6 = 10\n"
      },
      {
        "id": "6-dates",
        "lessonNumber": 6,
        "title": "Dates",
        "description": "输出今天和昨天的日期，并计算用户输入日期一周后的日期。",
        "taskFile": {
          "name": "code_challenge.py",
          "role": "task",
          "label": "题目代码",
          "code": "# print today's date\n# print yesterday's date\n# ask a user to enter a date\n# print the date one week from the date entered",
          "href": "../python-for-beginners/06%20-%20Dates/code_challenge.py"
        },
        "solutionFile": {
          "name": "code_challenge_solution.py",
          "role": "solution",
          "label": "参考答案",
          "code": "from datetime import datetime, timedelta\n\n# print today's date\ncurrent_date = datetime.now()\nprint(current_date)\n\n# print yesterday's date\none_day = timedelta(days=1)\nyesterday = current_date - one_day\nprint('Yesterday was: ' + str(yesterday))\n\n# ask a user to enter a date\ndate_entered = input('Please enter a date (dd/mm/yyyy): ')\ndate_entered = datetime.strptime(date_entered, '%d/%m/%Y')\n\n# print the date one week from the date entered\none_week = timedelta(weeks=1)\none_week_later = date_entered + one_week\nprint('One week later it will be: ' + str(one_week_later))",
          "href": "../python-for-beginners/06%20-%20Dates/code_challenge_solution.py"
        },
        "files": [
          {
            "name": "code_challenge_solution.py",
            "role": "solution",
            "label": "参考答案",
            "code": "from datetime import datetime, timedelta\n\n# print today's date\ncurrent_date = datetime.now()\nprint(current_date)\n\n# print yesterday's date\none_day = timedelta(days=1)\nyesterday = current_date - one_day\nprint('Yesterday was: ' + str(yesterday))\n\n# ask a user to enter a date\ndate_entered = input('Please enter a date (dd/mm/yyyy): ')\ndate_entered = datetime.strptime(date_entered, '%d/%m/%Y')\n\n# print the date one week from the date entered\none_week = timedelta(weeks=1)\none_week_later = date_entered + one_week\nprint('One week later it will be: ' + str(one_week_later))",
            "href": "../python-for-beginners/06%20-%20Dates/code_challenge_solution.py"
          },
          {
            "name": "code_challenge.py",
            "role": "task",
            "label": "题目代码",
            "code": "# print today's date\n# print yesterday's date\n# ask a user to enter a date\n# print the date one week from the date entered",
            "href": "../python-for-beginners/06%20-%20Dates/code_challenge.py"
          }
        ],
        "fileCount": 2,
        "preview": "# print today's date\n# print yesterday's date\n# ask a user to enter a date\n# print the date one week from the date entered"
      },
      {
        "id": "8-handling-conditions",
        "lessonNumber": 8,
        "title": "Handling conditions",
        "description": "修复税费条件判断中的类型转换、比较符和代码结构错误。",
        "taskFile": {
          "name": "code_challenge.py",
          "role": "task",
          "label": "题目代码",
          "code": "# Fix the mistakes in this code and test based on the description below\n# If I enter 2.00 I should see the message \"Tax rate is: 0.07\" \n# If I enter 1.00 I should see the message \"Tax rate is: 0.07\" \n# If I enter 0.50 I should see the message \"Tax rate is: 0\" \nprice = input('how much did you pay? ')\n\nif price > 1.00:\n\ttax = .07\n\tprint('Tax rate is: ' + str(tax))\nelse\n\ttax = 0\nprint('Tax rate is: ' + str(tax))",
          "href": "../python-for-beginners/08%20-%20Handling%20conditions/code_challenge.py"
        },
        "solutionFile": {
          "name": "code_challenge_solution.py",
          "role": "solution",
          "label": "参考答案",
          "code": "# Fix the mistakes in this code and test using the following\n# If I enter 2.00 I should see the message \"Tax rate is: 0.07\" \n# If I enter 1.00 I should see the message \"Tax rate is: 0.07\" \n# If I enter 0.50 I should see the message \"Tax rate is: 0\" \nprice = input('how much did you pay? ')\nprice = float(price)\n\nif price >= 1.00:\n\ttax = .07\n\tprint('Tax rate is: ' + str(tax))\nelse:\n    tax = 0\n    print('Tax rate is: ' + str(tax))",
          "href": "../python-for-beginners/08%20-%20Handling%20conditions/code_challenge_solution.py"
        },
        "files": [
          {
            "name": "code_challenge_solution.py",
            "role": "solution",
            "label": "参考答案",
            "code": "# Fix the mistakes in this code and test using the following\n# If I enter 2.00 I should see the message \"Tax rate is: 0.07\" \n# If I enter 1.00 I should see the message \"Tax rate is: 0.07\" \n# If I enter 0.50 I should see the message \"Tax rate is: 0\" \nprice = input('how much did you pay? ')\nprice = float(price)\n\nif price >= 1.00:\n\ttax = .07\n\tprint('Tax rate is: ' + str(tax))\nelse:\n    tax = 0\n    print('Tax rate is: ' + str(tax))",
            "href": "../python-for-beginners/08%20-%20Handling%20conditions/code_challenge_solution.py"
          },
          {
            "name": "code_challenge.py",
            "role": "task",
            "label": "题目代码",
            "code": "# Fix the mistakes in this code and test based on the description below\n# If I enter 2.00 I should see the message \"Tax rate is: 0.07\" \n# If I enter 1.00 I should see the message \"Tax rate is: 0.07\" \n# If I enter 0.50 I should see the message \"Tax rate is: 0\" \nprice = input('how much did you pay? ')\n\nif price > 1.00:\n\ttax = .07\n\tprint('Tax rate is: ' + str(tax))\nelse\n\ttax = 0\nprint('Tax rate is: ' + str(tax))",
            "href": "../python-for-beginners/08%20-%20Handling%20conditions/code_challenge.py"
          }
        ],
        "fileCount": 2,
        "preview": "# Fix the mistakes in this code and test based on the description below\n# If I enter 2.00 I should see the message \"Tax rate is: 0.07\" \n# If I enter 1.00 I should see the message \"Tax rate is: 0.07\" \n# If I enter 0.50 I should see the message \"Tax rate is: 0\" \nprice = input('how much did you pay? ')\n\nif price > 1.00:\n\ttax = .07\n\tprint('Tax rate is: ' + str(tax))\nelse\n\ttax = 0\nprint('Tax rate is: ' + str(tax))"
      },
      {
        "id": "9-handling-multiple-conditions",
        "lessonNumber": 9,
        "title": "Handling multiple conditions",
        "description": "根据名字首字母分配房间，并处理姓氏与默认房间条件。",
        "taskFile": {
          "name": "code_challenge.py",
          "role": "task",
          "label": "题目代码",
          "code": "# Ask a user their name\n# If their first name starts with A or B \n# tell them they go to room AB\n# IF their first name starts with C\n# tell them to go to room CD\n# If their first name starts with another letter, ask for their last name\n# IF their last name starts with Z, tell them to go to room Z\n# if their last name starts with any other letter, tell them to go to room OTHER\n# When you are done\n# Anna should be in room AB\n# Bob should be in room AB\n# Charlie should be in room C\n# Khalid Haque should be in room OTHER\n# Xin Zhao should be in room Z",
          "href": "../python-for-beginners/09%20-%20Handling%20multiple%20conditions/code_challenge.py"
        },
        "solutionFile": {
          "name": "code_challenge_solution.py",
          "role": "solution",
          "label": "参考答案",
          "code": "# Assign people to different rooms when they check in based on their names\n# When you are done\n# Anna should be in room AB\n# Bob should be in room AB\n# Charlie should be in room C\n# Khalid Haque should be in room OTHER\n# Xin Zhao should be in room Z\n# Ask a user their first name\nname = input('What is your name? ')\n\n# If their first name starts with A or B\n# tell them they go to room AB \nfirst_letter = name[0:1]\nif first_letter.upper() in ('A','B'):\n    room = 'AB'\n# If their first name starts with C\n# tell them to go to room C\nelif first_letter.upper() == 'C':\n    room = 'C'\nelse:\n    # If their first name starts with another letter, ask for their last name\n    # If their last name starts with Z, tell them to go to room Z\n    last_name = input('what is your last name? ')\n    last_name_first_letter = last_name[0:1]\n    # if their last name starts with any other letter, tell them to go to room OTHER\n    if last_name_first_letter == 'Z':\n        room = 'Z'\n    else:\n        room = 'OTHER'\nprint('Please go to room ' + room)\n\n",
          "href": "../python-for-beginners/09%20-%20Handling%20multiple%20conditions/code_challenge_solution.py"
        },
        "files": [
          {
            "name": "code_challenge_solution.py",
            "role": "solution",
            "label": "参考答案",
            "code": "# Assign people to different rooms when they check in based on their names\n# When you are done\n# Anna should be in room AB\n# Bob should be in room AB\n# Charlie should be in room C\n# Khalid Haque should be in room OTHER\n# Xin Zhao should be in room Z\n# Ask a user their first name\nname = input('What is your name? ')\n\n# If their first name starts with A or B\n# tell them they go to room AB \nfirst_letter = name[0:1]\nif first_letter.upper() in ('A','B'):\n    room = 'AB'\n# If their first name starts with C\n# tell them to go to room C\nelif first_letter.upper() == 'C':\n    room = 'C'\nelse:\n    # If their first name starts with another letter, ask for their last name\n    # If their last name starts with Z, tell them to go to room Z\n    last_name = input('what is your last name? ')\n    last_name_first_letter = last_name[0:1]\n    # if their last name starts with any other letter, tell them to go to room OTHER\n    if last_name_first_letter == 'Z':\n        room = 'Z'\n    else:\n        room = 'OTHER'\nprint('Please go to room ' + room)\n\n",
            "href": "../python-for-beginners/09%20-%20Handling%20multiple%20conditions/code_challenge_solution.py"
          },
          {
            "name": "code_challenge.py",
            "role": "task",
            "label": "题目代码",
            "code": "# Ask a user their name\n# If their first name starts with A or B \n# tell them they go to room AB\n# IF their first name starts with C\n# tell them to go to room CD\n# If their first name starts with another letter, ask for their last name\n# IF their last name starts with Z, tell them to go to room Z\n# if their last name starts with any other letter, tell them to go to room OTHER\n# When you are done\n# Anna should be in room AB\n# Bob should be in room AB\n# Charlie should be in room C\n# Khalid Haque should be in room OTHER\n# Xin Zhao should be in room Z",
            "href": "../python-for-beginners/09%20-%20Handling%20multiple%20conditions/code_challenge.py"
          }
        ],
        "fileCount": 2,
        "preview": "# Ask a user their name\n# If their first name starts with A or B \n# tell them they go to room AB\n# IF their first name starts with C\n# tell them to go to room CD\n# If their first name starts with another letter, ask for their last name\n# IF their last name starts with Z, tell them to go to room Z\n# if their last name starts with any other letter, tell them to go to room OTHER\n# When you are done\n# Anna should be in room AB\n# Bob should be in room AB\n# Charlie should be in room C"
      },
      {
        "id": "10-complex-conditon-checks",
        "lessonNumber": 10,
        "title": "Complex conditon checks",
        "description": "根据姓名长度决定球衣上显示的姓名格式。",
        "taskFile": {
          "name": "code_challenge.py",
          "role": "task",
          "label": "题目代码",
          "code": "# When you join a hockey team you get your name on the back of the jersey\n# but the jersey may not be big enough to hold all the letters\n# Ask the user for their first name\n\n# Ask the user for their last name\n\n# if first name is < 10 characters and last name is < 10 characters \n#       print first and last name on the jersey\n# if first name >= 10 characters long and last name is < 10 characters\n#       print first initial of first name and the entire last name\n# if first name < 10 characters long and last name is >= 10 characters\n#       print entire first name and first initial of last name\n# if first name >= 10 characters long and last name is >= 10 characters\n#       print last name only\n\n# Test with the following values\n# first name: Susan  last name: Ibach\n# output: Susan Ibach\n# first name: Susan  last name: ReallyLongLastName\n# output: Susan R.\n# first name: ReallyLongFirstName  last name: Ibach\n# output: R. Ibach\n# first name: ReallyLongFirstName  last name: ReallyLongLastName\n# output: ReallyLongLastName",
          "href": "../python-for-beginners/10%20-%20Complex%20conditon%20checks/code_challenge.py"
        },
        "solutionFile": {
          "name": "code_challenge_solution.py",
          "role": "solution",
          "label": "参考答案",
          "code": "# When you join a hockey team you get your name on the back of the jersey\n# but the jersey may not be big enough to hold all the letters\n# Ask the user for their first name\nfirst_name = input('Please enter your first name: ')\n# Ask the user for their last name\nlast_name = input('Please enter your last name: ')\n\n# if first name is < 10 characters and last name is < 10 characters \n#       print first and last name on the jersey\n# if first name >= 10 characters long and last name is < 10 characters\n#       print first initial of first name and the entire last name\n# if first name < 10 characters long and last name is >= 10 characters\n#       print entire first name and first initial of last name\n# if first name >= 10 characters long and last name is >= 10 characters\n#       print last name only\n\n# Check length of first name\nif len(first_name) >=10:\n    long_first_name = True\nelse:\n    long_first_name = False\n\n# Check length of last name\nif len(last_name) >= 10:\n    long_last_name = True\nelse:\n    long_last_name = False\n \n# Evaluate possible jersey print combinations for different lengths\nif long_first_name and long_last_name:\n    print(last_name)\nelif long_first_name:\n    print(first_name[0:1] + '. ' + last_name)\nelif long_last_name:\n    print(first_name + ' ' + last_name[0:1] + '.')\nelse:\n    print(first_name + ' ' + last_name)",
          "href": "../python-for-beginners/10%20-%20Complex%20conditon%20checks/code_challenge_solution.py"
        },
        "files": [
          {
            "name": "code_challenge_solution.py",
            "role": "solution",
            "label": "参考答案",
            "code": "# When you join a hockey team you get your name on the back of the jersey\n# but the jersey may not be big enough to hold all the letters\n# Ask the user for their first name\nfirst_name = input('Please enter your first name: ')\n# Ask the user for their last name\nlast_name = input('Please enter your last name: ')\n\n# if first name is < 10 characters and last name is < 10 characters \n#       print first and last name on the jersey\n# if first name >= 10 characters long and last name is < 10 characters\n#       print first initial of first name and the entire last name\n# if first name < 10 characters long and last name is >= 10 characters\n#       print entire first name and first initial of last name\n# if first name >= 10 characters long and last name is >= 10 characters\n#       print last name only\n\n# Check length of first name\nif len(first_name) >=10:\n    long_first_name = True\nelse:\n    long_first_name = False\n\n# Check length of last name\nif len(last_name) >= 10:\n    long_last_name = True\nelse:\n    long_last_name = False\n \n# Evaluate possible jersey print combinations for different lengths\nif long_first_name and long_last_name:\n    print(last_name)\nelif long_first_name:\n    print(first_name[0:1] + '. ' + last_name)\nelif long_last_name:\n    print(first_name + ' ' + last_name[0:1] + '.')\nelse:\n    print(first_name + ' ' + last_name)",
            "href": "../python-for-beginners/10%20-%20Complex%20conditon%20checks/code_challenge_solution.py"
          },
          {
            "name": "code_challenge.py",
            "role": "task",
            "label": "题目代码",
            "code": "# When you join a hockey team you get your name on the back of the jersey\n# but the jersey may not be big enough to hold all the letters\n# Ask the user for their first name\n\n# Ask the user for their last name\n\n# if first name is < 10 characters and last name is < 10 characters \n#       print first and last name on the jersey\n# if first name >= 10 characters long and last name is < 10 characters\n#       print first initial of first name and the entire last name\n# if first name < 10 characters long and last name is >= 10 characters\n#       print entire first name and first initial of last name\n# if first name >= 10 characters long and last name is >= 10 characters\n#       print last name only\n\n# Test with the following values\n# first name: Susan  last name: Ibach\n# output: Susan Ibach\n# first name: Susan  last name: ReallyLongLastName\n# output: Susan R.\n# first name: ReallyLongFirstName  last name: Ibach\n# output: R. Ibach\n# first name: ReallyLongFirstName  last name: ReallyLongLastName\n# output: ReallyLongLastName",
            "href": "../python-for-beginners/10%20-%20Complex%20conditon%20checks/code_challenge.py"
          }
        ],
        "fileCount": 2,
        "preview": "# When you join a hockey team you get your name on the back of the jersey\n# but the jersey may not be big enough to hold all the letters\n# Ask the user for their first name\n\n# Ask the user for their last name\n\n# if first name is < 10 characters and last name is < 10 characters \n#       print first and last name on the jersey\n# if first name >= 10 characters long and last name is < 10 characters\n#       print first initial of first name and the entire last name\n# if first name < 10 characters long and last name is >= 10 characters\n#       print entire first name and first initial of last name"
      },
      {
        "id": "13-functions",
        "lessonNumber": 13,
        "title": "Functions",
        "description": "实现接受三个参数的 calculator 函数并完成除法错误处理。",
        "taskFile": {
          "name": "code_challenge.py",
          "role": "task",
          "label": "题目代码",
          "code": "# Create a calculator function\n# The function should accept three parameters:\n# first_number: a numeric value for the math operation\n# second_number: a numeric value for the math operation\n# operation: the word 'add' or 'subtract'\n# the function should return the result of the two numbers added or subtracted\n# based on the value passed in for the operator\n#\n# Test your function with the values 6,4, add \n# Should return 10\n#\n# Test your function with the values 6,4, subtract \n# Should return 2\n# \n# BONUS: Test your function with the values 6, 4 and divide \n# Have your function return an error message when invalid values are received\n\n",
          "href": "../python-for-beginners/13%20-%20Functions/code_challenge.py"
        },
        "solutionFile": {
          "name": "code_challenge_solution.py",
          "role": "solution",
          "label": "参考答案",
          "code": "# Create a calculator function\n# The function should accept three parameters:\n# first_number: a numeric value for the math operation\n# second_number: a numeric value for the math operation\n# operation: the word 'add' or 'subtract'\n# the function should return the result of the two numbers added or subtracted\n# based on the value passed in for the operator\n#\n\ndef calculator(first_number, second_number, operation):\n    if operation.upper() == 'ADD':\n        return(float(first_number) + float(second_number))\n    elif operation.upper() =='SUBTRACT':\n        return(float(first_number) - float(second_number))\n    else:\n        return('Invalid operation please specify ADD or SUBTRACT')\n# Test your function with the values 6,4, add \n# Should return 10\n#\nprint('Adding 6 + 4 = ' + str(calculator(6,4,'add')))\n# Test your function with the values 6,4, subtract \n# Should return 2\nprint('Subtracting 6 - 4 = ' + str(calculator(6,4,'subtract')))\n# Test your function with the values 6,4, divide \n# Should return some sort of error message\nprint('Dividing 6 / 4 = ' + str(calculator(6,4,'divide')))",
          "href": "../python-for-beginners/13%20-%20Functions/code_challenge_solution.py"
        },
        "files": [
          {
            "name": "code_challenge_solution.py",
            "role": "solution",
            "label": "参考答案",
            "code": "# Create a calculator function\n# The function should accept three parameters:\n# first_number: a numeric value for the math operation\n# second_number: a numeric value for the math operation\n# operation: the word 'add' or 'subtract'\n# the function should return the result of the two numbers added or subtracted\n# based on the value passed in for the operator\n#\n\ndef calculator(first_number, second_number, operation):\n    if operation.upper() == 'ADD':\n        return(float(first_number) + float(second_number))\n    elif operation.upper() =='SUBTRACT':\n        return(float(first_number) - float(second_number))\n    else:\n        return('Invalid operation please specify ADD or SUBTRACT')\n# Test your function with the values 6,4, add \n# Should return 10\n#\nprint('Adding 6 + 4 = ' + str(calculator(6,4,'add')))\n# Test your function with the values 6,4, subtract \n# Should return 2\nprint('Subtracting 6 - 4 = ' + str(calculator(6,4,'subtract')))\n# Test your function with the values 6,4, divide \n# Should return some sort of error message\nprint('Dividing 6 / 4 = ' + str(calculator(6,4,'divide')))",
            "href": "../python-for-beginners/13%20-%20Functions/code_challenge_solution.py"
          },
          {
            "name": "code_challenge.py",
            "role": "task",
            "label": "题目代码",
            "code": "# Create a calculator function\n# The function should accept three parameters:\n# first_number: a numeric value for the math operation\n# second_number: a numeric value for the math operation\n# operation: the word 'add' or 'subtract'\n# the function should return the result of the two numbers added or subtracted\n# based on the value passed in for the operator\n#\n# Test your function with the values 6,4, add \n# Should return 10\n#\n# Test your function with the values 6,4, subtract \n# Should return 2\n# \n# BONUS: Test your function with the values 6, 4 and divide \n# Have your function return an error message when invalid values are received\n\n",
            "href": "../python-for-beginners/13%20-%20Functions/code_challenge.py"
          }
        ],
        "fileCount": 2,
        "preview": "# Create a calculator function\n# The function should accept three parameters:\n# first_number: a numeric value for the math operation\n# second_number: a numeric value for the math operation\n# operation: the word 'add' or 'subtract'\n# the function should return the result of the two numbers added or subtracted\n# based on the value passed in for the operator\n#\n# Test your function with the values 6,4, add \n# Should return 10\n#\n# Test your function with the values 6,4, subtract "
      },
      {
        "id": "14-function-parameters",
        "lessonNumber": 14,
        "title": "Function parameters",
        "description": "为 calculator 函数增加默认参数与命名参数调用。",
        "taskFile": {
          "name": "code_challenge.py",
          "role": "task",
          "label": "题目代码",
          "code": "# Create a calculator function\n# The function should accept three parameters:\n# first_number: a numeric value for the math operation\n# second_number: a numeric value for the math operation\n# operation: the word 'add' or 'subtract'. The default operation is 'add'\n# the function should return the result of the two numbers added or subtracted\n# based on the value passed in for the operator\n#\n# Test your function using named notation passing in only the numbers 6 and 4\n# Should return 10\n#\n# Test your function using named notation with the values 6,4, subtract \n# Should return 2\n# \n# BONUS: Test your function with the values 6, 4 and divide \n# Have your function return an error message when invalid values are received\n",
          "href": "../python-for-beginners/14%20-%20Function%20parameters/code_challenge.py"
        },
        "solutionFile": {
          "name": "code_challenge_solution.py",
          "role": "solution",
          "label": "参考答案",
          "code": "# Create a calculator function\n# The function should accept three parameters:\n# first_number: a numeric value for the math operation\n# second_number: a numeric value for the math operation\n# operation: the word 'add' or 'subtract'. The default operation is 'add'\n# the function should return the result of the two numbers added or subtracted\n# based on the value passed in for the operator\n#\ndef calculator(first_number, second_number, operation='ADD'):\n    if operation.upper() == 'ADD':\n        return(float(first_number) + float(second_number))\n    elif operation.upper() =='SUBTRACT':\n        return(float(first_number) - float(second_number))\n    else:\n        return('Invalid operation please specify ADD or SUBTRACT')\n\n\n# Test your function using named notation passing in only the numbers 6 and 4\n# Should return 10\n\nprint('Adding 6 + 4 = ' + str(calculator(first_number=6, second_number=4)))\n# Test your function using named notation with the values 6,4, subtract \n# Should return 2\n#\nprint('Subtracting 6 - 4 = ' + str(calculator(first_number=6, second_number=4, operation='subtract')))\n",
          "href": "../python-for-beginners/14%20-%20Function%20parameters/code_challenge_solution.py"
        },
        "files": [
          {
            "name": "code_challenge_solution.py",
            "role": "solution",
            "label": "参考答案",
            "code": "# Create a calculator function\n# The function should accept three parameters:\n# first_number: a numeric value for the math operation\n# second_number: a numeric value for the math operation\n# operation: the word 'add' or 'subtract'. The default operation is 'add'\n# the function should return the result of the two numbers added or subtracted\n# based on the value passed in for the operator\n#\ndef calculator(first_number, second_number, operation='ADD'):\n    if operation.upper() == 'ADD':\n        return(float(first_number) + float(second_number))\n    elif operation.upper() =='SUBTRACT':\n        return(float(first_number) - float(second_number))\n    else:\n        return('Invalid operation please specify ADD or SUBTRACT')\n\n\n# Test your function using named notation passing in only the numbers 6 and 4\n# Should return 10\n\nprint('Adding 6 + 4 = ' + str(calculator(first_number=6, second_number=4)))\n# Test your function using named notation with the values 6,4, subtract \n# Should return 2\n#\nprint('Subtracting 6 - 4 = ' + str(calculator(first_number=6, second_number=4, operation='subtract')))\n",
            "href": "../python-for-beginners/14%20-%20Function%20parameters/code_challenge_solution.py"
          },
          {
            "name": "code_challenge.py",
            "role": "task",
            "label": "题目代码",
            "code": "# Create a calculator function\n# The function should accept three parameters:\n# first_number: a numeric value for the math operation\n# second_number: a numeric value for the math operation\n# operation: the word 'add' or 'subtract'. The default operation is 'add'\n# the function should return the result of the two numbers added or subtracted\n# based on the value passed in for the operator\n#\n# Test your function using named notation passing in only the numbers 6 and 4\n# Should return 10\n#\n# Test your function using named notation with the values 6,4, subtract \n# Should return 2\n# \n# BONUS: Test your function with the values 6, 4 and divide \n# Have your function return an error message when invalid values are received\n",
            "href": "../python-for-beginners/14%20-%20Function%20parameters/code_challenge.py"
          }
        ],
        "fileCount": 2,
        "preview": "# Create a calculator function\n# The function should accept three parameters:\n# first_number: a numeric value for the math operation\n# second_number: a numeric value for the math operation\n# operation: the word 'add' or 'subtract'. The default operation is 'add'\n# the function should return the result of the two numbers added or subtracted\n# based on the value passed in for the operator\n#\n# Test your function using named notation passing in only the numbers 6 and 4\n# Should return 10\n#\n# Test your function using named notation with the values 6,4, subtract "
      },
      {
        "id": "16-calling-apis",
        "lessonNumber": 16,
        "title": "Calling APIs",
        "description": "调用 Azure Custom Vision API，并完成 OCR 拓展挑战。",
        "taskFile": {
          "name": "code_challenge.py",
          "role": "task",
          "label": "题目代码",
          "code": "# Challenge #1\n# Create an Azure Custom Vision Service \n# Analyze an image and return the JSON describing the image.\n# call_api.py is a completed solution, but it will not run unless\n# you do the following:\n#   Create a Custom Vision Service in Azure\n#   Update the Key \n#   Update the address of your service\n#   Update the image file and location\n\n# Bonus Challenge \n# Your skills are growing, it's time to start trying to figure things out on your own\n# based on documentation. You have already called one function of the Computer Vision Service\n# Now try calling another\n# Instead of calling the analyze method of the service, try calling the OCR method \n# Here is some helpful documentation\n# https://docs.microsoft.com/azure/cognitive-services/Computer-vision/concept-recognizing-text#ocr-optical-character-recognition-api\n# https://westus.dev.cognitive.microsoft.com/docs/services/5adf991815e1060e6355ad44/operations/56f91f2e778daf14a499e1fc\n# Use the documentation to figure out\n#    The correct function name for the address\n#    The parameters you need to pass the function\n#    The HTTP Headers required    \n# Pass in an image containing text\n# The JSON returned will contain the string of text in the image\n# Good luck!\n",
          "href": "../python-for-beginners/16%20-%20Calling%20APIs/code_challenge.py"
        },
        "files": [
          {
            "name": "code_challenge.py",
            "role": "task",
            "label": "题目代码",
            "code": "# Challenge #1\n# Create an Azure Custom Vision Service \n# Analyze an image and return the JSON describing the image.\n# call_api.py is a completed solution, but it will not run unless\n# you do the following:\n#   Create a Custom Vision Service in Azure\n#   Update the Key \n#   Update the address of your service\n#   Update the image file and location\n\n# Bonus Challenge \n# Your skills are growing, it's time to start trying to figure things out on your own\n# based on documentation. You have already called one function of the Computer Vision Service\n# Now try calling another\n# Instead of calling the analyze method of the service, try calling the OCR method \n# Here is some helpful documentation\n# https://docs.microsoft.com/azure/cognitive-services/Computer-vision/concept-recognizing-text#ocr-optical-character-recognition-api\n# https://westus.dev.cognitive.microsoft.com/docs/services/5adf991815e1060e6355ad44/operations/56f91f2e778daf14a499e1fc\n# Use the documentation to figure out\n#    The correct function name for the address\n#    The parameters you need to pass the function\n#    The HTTP Headers required    \n# Pass in an image containing text\n# The JSON returned will contain the string of text in the image\n# Good luck!\n",
            "href": "../python-for-beginners/16%20-%20Calling%20APIs/code_challenge.py"
          }
        ],
        "fileCount": 1,
        "preview": "# Challenge #1\n# Create an Azure Custom Vision Service \n# Analyze an image and return the JSON describing the image.\n# call_api.py is a completed solution, but it will not run unless\n# you do the following:\n#   Create a Custom Vision Service in Azure\n#   Update the Key \n#   Update the address of your service\n#   Update the image file and location\n\n# Bonus Challenge \n# Your skills are growing, it's time to start trying to figure things out on your own"
      }
    ]
  }
};
