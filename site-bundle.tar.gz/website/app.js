(() => {
  const courseData = window.COURSE_DATA;

  if (!courseData || !Array.isArray(courseData.tracks)) {
    throw new Error("Course data was not loaded.");
  }

  const main = document.querySelector("#main-content");
  const trackNav = document.querySelector("#track-nav");
  const searchInput = document.querySelector("#course-search");
  const sidebarProgressValue = document.querySelector(
    "#sidebar-progress-value",
  );
  const sidebarProgressBar = document.querySelector("#sidebar-progress-bar");
  const sidebarProgressCopy = document.querySelector(
    "#sidebar-progress-copy",
  );
  const videoOverlay = document.querySelector("#video-overlay");
  const videoPlayer = document.querySelector("#video-player");
  const videoTitle = document.querySelector("#video-title");
  const videoKicker = document.querySelector("#video-kicker");
  const videoDescription = document.querySelector("#video-description");
  const videoSource = document.querySelector("#video-source");
  const videoClose = document.querySelector("#video-close");
  const videoSubtitleControl = document.querySelector(
    "#video-subtitle-control",
  );
  const progressKey = "c9-python-course-progress-v1";

  const state = {
    activeTrack: "overview",
    search: "",
    completionFilter: "all",
    subtitleLanguage: "zh",
    selectedAssignment: "",
    codeMode: "task",
  };

  let progress = readProgress();

  const navItems = [
    {
      id: "overview",
      title: "全部课程",
      description: "课程总览与学习路径",
      icon: "layout-dashboard",
    },
    {
      id: "basics",
      title: "Python 基础",
      description: "44 节入门视频",
      icon: "circle-play",
    },
    {
      id: "more",
      title: "Python 进阶",
      description: "20 节进阶视频",
      icon: "layers-3",
    },
    {
      id: "data",
      title: "数据工具",
      description: "15 个 Notebook",
      icon: "chart-no-axes-combined",
    },
    {
      id: "assignments",
      title: "作业练习",
      description: "19 个代码文件",
      icon: "clipboard-list",
    },
  ];

  const lessonIndex = new Map();

  for (const track of courseData.tracks) {
    for (const lesson of track.lessons) {
      lessonIndex.set(lessonKey(track.id, lesson), { ...lesson, track });
    }
  }

  function lessonKey(trackId, lesson) {
    return `${trackId}:${lesson.id || lesson.number}`;
  }

  function readProgress() {
    try {
      return JSON.parse(localStorage.getItem(progressKey) || "{}");
    } catch {
      return {};
    }
  }

  function saveProgress() {
    localStorage.setItem(progressKey, JSON.stringify(progress));
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function formatClock(milliseconds) {
    const totalSeconds = Math.max(0, Math.round(milliseconds / 1000));
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    if (hours > 0) {
      return `${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
    }

    return `${minutes}:${String(seconds).padStart(2, "0")}`;
  }

  function formatDuration(milliseconds) {
    const totalMinutes = Math.round(milliseconds / 60000);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;

    if (!hours) {
      return `${minutes} 分钟`;
    }

    return minutes ? `${hours} 小时 ${minutes} 分` : `${hours} 小时`;
  }

  function getAllLessons() {
    return courseData.tracks.flatMap((track) =>
      track.lessons.map((lesson) => ({ lesson, track })),
    );
  }

  function isLessonComplete(track, lesson) {
    return Boolean(progress[lessonKey(track.id, lesson)]);
  }

  function getTrackProgress(track) {
    const complete = track.lessons.filter((lesson) =>
      isLessonComplete(track, lesson),
    ).length;
    const total = track.lessons.length || 1;
    return {
      complete,
      total: track.lessons.length,
      percent: Math.round((complete / total) * 100),
    };
  }

  function getOverallProgress() {
    const allLessons = getAllLessons();
    const complete = allLessons.filter(({ lesson, track }) =>
      isLessonComplete(track, lesson),
    ).length;
    const total = allLessons.length || 1;
    return {
      complete,
      total: allLessons.length,
      percent: Math.round((complete / total) * 100),
    };
  }

  function renderIcons() {
    if (window.lucide) {
      window.lucide.createIcons();
    }
  }

  function renderProgress() {
    const overall = getOverallProgress();
    sidebarProgressValue.textContent = `${overall.percent}%`;
    sidebarProgressBar.style.width = `${overall.percent}%`;
    sidebarProgressCopy.textContent = `已完成 ${overall.complete} / ${overall.total} 节`;
  }

  function renderNavigation() {
    trackNav.innerHTML = navItems
      .map((item) => {
        const track = courseData.tracks.find((entry) => entry.id === item.id);
        const count =
          item.id === "overview"
            ? getAllLessons().length
            : item.id === "assignments"
              ? courseData.assignments.fileCount
              : track?.lessonCount;
        const active = state.activeTrack === item.id ? "active" : "";

        return `
          <button class="track-nav-button ${active}" type="button" data-track="${item.id}">
            <span class="track-nav-icon">
              <i data-lucide="${item.icon}"></i>
            </span>
            <span class="track-nav-copy">
              <strong>${escapeHtml(item.title)}</strong>
              <span>${escapeHtml(item.description)}</span>
            </span>
            <span class="track-nav-count">${count}</span>
          </button>
        `;
      })
      .join("");
  }

  function getCompletionFilterLabel(filter) {
    return {
      all: "全部",
      pending: "未完成",
      complete: "已完成",
    }[filter];
  }

  function renderToolbar(track, visibleCount) {
    return `
      <div class="course-toolbar">
        <div class="segmented-control" aria-label="完成状态筛选">
          ${["all", "pending", "complete"]
            .map(
              (filter) => `
                <button
                  class="${state.completionFilter === filter ? "active" : ""}"
                  type="button"
                  data-completion-filter="${filter}"
                >
                  ${getCompletionFilterLabel(filter)}
                </button>
              `,
            )
            .join("")}
        </div>
        <span class="result-count">
          ${visibleCount} / ${track.lessonCount} 项内容
        </span>
      </div>
    `;
  }

  function renderVideoCard(track, lesson) {
    const key = lessonKey(track.id, lesson);
    const complete = isLessonComplete(track, lesson);
    const numberLabel =
      track.id === "basics" ? `第 ${lesson.number} 课` : `第 ${lesson.number} 节`;

    return `
      <article class="lesson-card ${complete ? "complete" : ""}">
        <button
          class="lesson-media"
          type="button"
          data-action="play"
          data-key="${escapeHtml(key)}"
          aria-label="播放 ${escapeHtml(lesson.title)}"
        >
          <img
            src="${escapeHtml(lesson.thumbnail)}"
            alt=""
            loading="lazy"
            referrerpolicy="no-referrer"
          />
          <span class="play-button" aria-hidden="true">
            <i data-lucide="play"></i>
          </span>
          <span class="lesson-badges">
            <span class="lesson-badge">
              <i data-lucide="hash"></i>
              ${numberLabel}
            </span>
            <span class="lesson-badge">
              <i data-lucide="clock-3"></i>
              ${formatClock(lesson.durationMs)}
            </span>
          </span>
        </button>
        <div class="lesson-body">
          <h3 class="lesson-title">${escapeHtml(lesson.title)}</h3>
          <p class="lesson-description">Microsoft Learn 原课视频，可直接在站内播放。</p>
          <div class="lesson-footer">
            <div class="lesson-actions">
              <button
                class="mini-button ${complete ? "complete" : ""}"
                type="button"
                data-action="toggle-complete"
                data-key="${escapeHtml(key)}"
              >
                <i data-lucide="${complete ? "circle-check" : "circle"}"></i>
                ${complete ? "已完成" : "标记完成"}
              </button>
            </div>
            <a
              class="lesson-source"
              href="${escapeHtml(lesson.pageUrl)}"
              target="_blank"
              rel="noreferrer"
            >
              原页面
              <i data-lucide="external-link"></i>
            </a>
          </div>
        </div>
      </article>
    `;
  }

  function renderNotebookCard(track, lesson) {
    const key = lessonKey(track.id, lesson);
    const complete = isLessonComplete(track, lesson);
    const isNotebook = lesson.type === "notebook";

    return `
      <article class="lesson-card ${complete ? "complete" : ""}">
        <a
          class="lesson-media notebook-icon"
          href="${escapeHtml(lesson.href)}"
          target="_blank"
          rel="noreferrer"
          aria-label="打开 ${escapeHtml(lesson.title)}"
        >
          <i data-lucide="${isNotebook ? "notebook-tabs" : "book-open-text"}"></i>
        </a>
        <div class="lesson-body">
          <h3 class="lesson-title">${escapeHtml(lesson.title)}</h3>
          <p class="lesson-description">${escapeHtml(lesson.description)}</p>
          <div class="lesson-footer">
            <div class="lesson-actions">
              <button
                class="mini-button ${complete ? "complete" : ""}"
                type="button"
                data-action="toggle-complete"
                data-key="${escapeHtml(key)}"
              >
                <i data-lucide="${complete ? "circle-check" : "circle"}"></i>
                ${complete ? "已完成" : "标记完成"}
              </button>
            </div>
            <a
              class="lesson-source"
              href="${escapeHtml(lesson.href)}"
              target="_blank"
              rel="noreferrer"
            >
              ${isNotebook ? "打开 Notebook" : "查看资料"}
              <i data-lucide="arrow-up-right"></i>
            </a>
          </div>
        </div>
      </article>
    `;
  }

  function lessonMatchesSearch(track, lesson, query) {
    const searchable = [
      lesson.title,
      lesson.description,
      lesson.rawTitle,
      track.title,
      track.shortTitle,
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();

    return searchable.includes(query);
  }

  function assignmentMatchesSearch(assignment, query) {
    if (!query) {
      return true;
    }

    const searchable = [
      assignment.title,
      assignment.description,
      assignment.lessonNumber,
      ...assignment.files.map((file) => file.name),
      ...assignment.files.map((file) => file.code),
    ]
      .join(" ")
      .toLowerCase();

    return searchable.includes(query);
  }

  function renderAssignmentCard(assignment) {
    const solutionButton = assignment.solutionFile
      ? `
        <button
          class="mini-button"
          type="button"
          data-action="view-assignment"
          data-assignment="${escapeHtml(assignment.id)}"
          data-code-mode="solution"
        >
          <i data-lucide="circle-check"></i>
          参考答案
        </button>
      `
      : "";

    return `
      <article class="assignment-card">
        <div class="assignment-card-header">
          <span class="assignment-number">作业 ${String(
            assignment.lessonNumber,
          ).padStart(2, "0")}</span>
          <span class="assignment-file-count">
            ${assignment.fileCount} 个文件
          </span>
        </div>
        <h3>${escapeHtml(assignment.title)}</h3>
        <p>${escapeHtml(assignment.description)}</p>
        <pre class="assignment-preview"><code>${escapeHtml(
          assignment.preview,
        )}</code></pre>
        <div class="assignment-card-actions">
          <button
            class="mini-button"
            type="button"
            data-action="view-assignment"
            data-assignment="${escapeHtml(assignment.id)}"
            data-code-mode="task"
          >
            <i data-lucide="code-2"></i>
            查看完整题目
          </button>
          ${solutionButton}
          <a
            class="lesson-source"
            href="${escapeHtml(assignment.taskFile.href)}"
            target="_blank"
            rel="noreferrer"
          >
            原文件
            <i data-lucide="external-link"></i>
          </a>
        </div>
      </article>
    `;
  }

  function renderAssignmentViewer(assignment) {
    const activeFile =
      assignment.files.find((file) => file.role === state.codeMode) ||
      assignment.taskFile;
    const solutionMode = activeFile.role === "solution";

    return `
      <section id="assignment-viewer" class="assignment-viewer">
        <header class="assignment-viewer-header">
          <div>
            <span class="assignment-viewer-kicker">
              作业 ${String(assignment.lessonNumber).padStart(2, "0")}
            </span>
            <h2>${escapeHtml(assignment.title)}</h2>
            <p>${escapeHtml(activeFile.name)}</p>
          </div>
          <button
            class="icon-button assignment-viewer-close"
            type="button"
            data-action="close-assignment"
            aria-label="关闭代码查看器"
          >
            <i data-lucide="x"></i>
          </button>
        </header>
        <div class="assignment-viewer-toolbar">
          <div class="segmented-control" aria-label="代码文件">
            <button
              class="${!solutionMode ? "active" : ""}"
              type="button"
              data-code-mode="task"
              data-assignment="${escapeHtml(assignment.id)}"
            >
              题目代码
            </button>
            <button
              class="${solutionMode ? "active" : ""}"
              type="button"
              data-code-mode="solution"
              data-assignment="${escapeHtml(assignment.id)}"
              ${assignment.solutionFile ? "" : "disabled"}
            >
              参考答案
            </button>
          </div>
          <div class="assignment-viewer-actions">
            <button
              class="mini-button"
              type="button"
              data-action="copy-code"
              data-assignment="${escapeHtml(assignment.id)}"
            >
              <i data-lucide="copy"></i>
              复制代码
            </button>
            <a
              class="mini-button"
              href="${escapeHtml(activeFile.href)}"
              target="_blank"
              rel="noreferrer"
            >
              <i data-lucide="external-link"></i>
              打开原文件
            </a>
          </div>
        </div>
        <pre class="assignment-code"><code>${escapeHtml(
          activeFile.code,
        )}</code></pre>
      </section>
    `;
  }

  function renderAssignments() {
    const query = state.search.trim().toLowerCase();
    const filteredAssignments = courseData.assignments.groups.filter(
      (assignment) => assignmentMatchesSearch(assignment, query),
    );
    const selectedAssignment = courseData.assignments.groups.find(
      (assignment) => assignment.id === state.selectedAssignment,
    );
    const cards = filteredAssignments
      .map((assignment) => renderAssignmentCard(assignment))
      .join("");

    main.innerHTML = `
      <section class="course-hero">
        <p class="eyebrow">
          <i data-lucide="clipboard-list"></i>
          Coding Challenges
        </p>
        <h1>Python 作业练习</h1>
        <p>
          已完整提取基础课程中的代码挑战，共 10 组练习、19 个文件。
          查看完整题目、参考答案、原文件和代码内容。
        </p>
        <div class="hero-actions">
          <a
            class="button button-primary"
            href="https://github.com/microsoft/c9-python-getting-started/tree/master/python-for-beginners"
            target="_blank"
            rel="noreferrer"
          >
            <i data-lucide="github"></i>
            GitHub 作业目录
          </a>
          <button
            class="button button-quiet"
            type="button"
            data-action="close-assignment"
          >
            <i data-lucide="list"></i>
            浏览全部作业
          </button>
        </div>
      </section>

      <section class="stats-grid" aria-label="作业统计">
        <article class="stat-card">
          <span>练习组数</span>
          <strong>${courseData.assignments.exerciseCount}</strong>
        </article>
        <article class="stat-card">
          <span>作业文件</span>
          <strong>${courseData.assignments.fileCount}</strong>
        </article>
        <article class="stat-card">
          <span>参考答案</span>
          <strong>${courseData.assignments.solutionCount}</strong>
        </article>
        <article class="stat-card">
          <span>主要语言</span>
          <strong>Python</strong>
        </article>
      </section>

      ${
        selectedAssignment
          ? renderAssignmentViewer(selectedAssignment)
          : ""
      }

      <div class="section-heading">
        <div>
          <h2>全部作业</h2>
          <p>${filteredAssignments.length} 组练习，代码内容已完整收录。</p>
        </div>
      </div>

      ${
        cards
          ? `<section class="assignment-grid">${cards}</section>`
          : `
            <section class="empty-state">
              <div>
                <i data-lucide="search-x"></i>
                <h2>没有找到匹配作业</h2>
                <p>尝试搜索“calculator”“日期”“函数”或作业编号。</p>
              </div>
            </section>
          `
      }
    `;
  }

  function filterTrackLessons(track, query) {
    return track.lessons.filter((lesson) => {
      if (query && !lessonMatchesSearch(track, lesson, query)) {
        return false;
      }

      const complete = isLessonComplete(track, lesson);
      if (state.completionFilter === "complete" && !complete) {
        return false;
      }
      if (state.completionFilter === "pending" && complete) {
        return false;
      }
      return true;
    });
  }

  function renderTrackCards() {
    return courseData.tracks
      .map((track, index) => {
        const trackProgress = getTrackProgress(track);
        const meta = navItems.find((item) => item.id === track.id);

        return `
          <article class="track-card" data-open-track="${track.id}">
            <div>
              <div class="track-card-top">
                <span class="track-icon ${track.accent}">
                  <i data-lucide="${meta?.icon || "book-open"}"></i>
                </span>
                <span class="track-index">路径 ${String(index + 1).padStart(2, "0")}</span>
              </div>
              <h3>${escapeHtml(track.title)}</h3>
              <p>${escapeHtml(track.description)}</p>
            </div>
            <div class="track-card-footer">
              <span><strong>${trackProgress.complete}</strong> / ${trackProgress.total} 已完成</span>
              <span>${track.videoCount ? `${track.videoCount} 个视频` : `${track.lessonCount} 个资料`}</span>
            </div>
          </article>
        `;
      })
      .join("");
  }

  function renderOverview() {
    const allLessons = getAllLessons();
    const videoLessons = allLessons.filter(
      ({ lesson }) => lesson.videoUrl,
    ).length;
    const notebookLessons = allLessons.filter(
      ({ lesson }) => lesson.type === "notebook",
    ).length;
    const totalDuration = courseData.tracks.reduce(
      (sum, track) => sum + track.durationMs,
      0,
    );

    main.innerHTML = `
      <section class="course-hero">
        <p class="eyebrow">
          <i data-lucide="sparkles"></i>
          Microsoft Python Course
        </p>
        <h1>Python 课程学习中心</h1>
        <p>
          按基础、进阶和数据分析三个路径整理全部课程。视频可在当前页面直接播放，
          Notebook 和配套资料可以直接打开。
        </p>
        <div class="hero-actions">
          <button class="button button-primary" type="button" data-open-track="basics">
            <i data-lucide="play"></i>
            开始 Python 基础
          </button>
          <button class="button button-quiet" type="button" data-open-track="data">
            <i data-lucide="notebook-tabs"></i>
            查看数据工具
          </button>
          <button class="button button-quiet" type="button" data-open-track="assignments">
            <i data-lucide="clipboard-list"></i>
            查看 19 个作业文件
          </button>
        </div>
      </section>

      <section class="stats-grid" aria-label="课程统计">
        <article class="stat-card">
          <span>课程内容</span>
          <strong>${allLessons.length}</strong>
        </article>
        <article class="stat-card">
          <span>视频课程</span>
          <strong>${videoLessons}</strong>
        </article>
        <article class="stat-card">
          <span>视频总时长</span>
          <strong>${formatDuration(totalDuration)}</strong>
        </article>
        <article class="stat-card">
          <span>Notebook</span>
          <strong>${notebookLessons}</strong>
        </article>
      </section>

      <div class="section-heading">
        <div>
          <h2>学习路径</h2>
          <p>从 Python 基础开始，再进入进阶语法和数据处理。</p>
        </div>
      </div>
      <section class="track-grid">
        ${renderTrackCards()}
      </section>

      <div class="section-heading">
        <div>
          <h2>推荐顺序</h2>
          <p>先完成路径 1，再逐步进入后续内容。</p>
        </div>
      </div>
      <section class="path-list">
        ${courseData.tracks
          .map(
            (track, index) => `
              <article class="path-step">
                <span class="path-number">${index + 1}</span>
                <div>
                  <h3>${escapeHtml(track.title)}</h3>
                  <p>${escapeHtml(track.description)}</p>
                </div>
                <button class="button button-quiet" type="button" data-open-track="${track.id}">
                  打开课程
                  <i data-lucide="arrow-right"></i>
                </button>
              </article>
            `,
          )
          .join("")}
      </section>

      <div class="section-heading">
        <div>
          <h2>作业与代码挑战</h2>
          <p>从基础课程中完整提取的练习题和参考答案。</p>
        </div>
      </div>
      <section class="assignment-spotlight">
        <div class="assignment-spotlight-icon">
          <i data-lucide="clipboard-check"></i>
        </div>
        <div>
          <h3>10 组练习，19 个 Python 文件</h3>
          <p>
            包含打印、变量、日期、条件、函数、参数和 API 调用。
            可以查看完整代码并对照 9 份参考答案。
          </p>
        </div>
        <button
          class="button button-primary"
          type="button"
          data-open-track="assignments"
        >
          打开作业区
          <i data-lucide="arrow-right"></i>
        </button>
      </section>
    `;
  }

  function renderSearchResults() {
    const query = state.search.trim().toLowerCase();
    const matches = getAllLessons().filter(({ track, lesson }) =>
      lessonMatchesSearch(track, lesson, query),
    );
    const assignmentMatches = courseData.assignments.groups.filter(
      (assignment) => assignmentMatchesSearch(assignment, query),
    );

    const lessonCards = matches
      .map(({ track, lesson }) =>
        lesson.videoUrl
          ? renderVideoCard(track, lesson)
          : renderNotebookCard(track, lesson),
      )
      .join("");
    const assignmentCards = assignmentMatches
      .map((assignment) => renderAssignmentCard(assignment))
      .join("");
    const totalMatches = matches.length + assignmentMatches.length;

    main.innerHTML = `
      <section class="course-hero">
        <p class="eyebrow">
          <i data-lucide="search"></i>
          Search Results
        </p>
        <h1>“${escapeHtml(state.search)}”</h1>
        <p>找到 ${totalMatches} 项匹配内容，包括课程和作业代码。</p>
      </section>
      <div class="section-heading">
        <div>
          <h2>搜索结果</h2>
          <p>搜索范围包含课程标题、作业描述和完整代码。</p>
        </div>
      </div>
      ${
        totalMatches
          ? `
            ${
              lessonCards
                ? `
                  <div class="section-heading">
                    <div>
                      <h2>课程内容</h2>
                      <p>${matches.length} 项匹配课程。</p>
                    </div>
                  </div>
                  <section class="lesson-grid">${lessonCards}</section>
                `
                : ""
            }
            ${
              assignmentCards
                ? `
                  <div class="section-heading">
                    <div>
                      <h2>作业练习</h2>
                      <p>${assignmentMatches.length} 组匹配作业。</p>
                    </div>
                  </div>
                  <section class="assignment-grid">${assignmentCards}</section>
                `
                : ""
            }
          `
          : `
            <section class="empty-state">
              <div>
                <i data-lucide="search-x"></i>
                <h2>没有找到匹配内容</h2>
                <p>尝试搜索“函数”“Pandas”“calculator”或课程编号。</p>
              </div>
            </section>
          `
      }
    `;
  }

  function renderTrack(track) {
    const query = state.search.trim().toLowerCase();
    const filteredLessons = filterTrackLessons(track, query);
    const cards = filteredLessons
      .map((lesson) =>
        lesson.videoUrl
          ? renderVideoCard(track, lesson)
          : renderNotebookCard(track, lesson),
      )
      .join("");
    const trackProgress = getTrackProgress(track);
    const hasVideo = track.videoCount > 0;

    main.innerHTML = `
      <section class="course-hero">
        <p class="eyebrow">
          <i data-lucide="${track.id === "data" ? "database" : "play-circle"}"></i>
          ${hasVideo ? "Video Course" : "Notebook Course"}
        </p>
        <h1>${escapeHtml(track.title)}</h1>
        <p>${escapeHtml(track.description)}</p>
        <div class="hero-actions">
          <button class="button button-primary" type="button" data-action="continue-track" data-track="${track.id}">
            <i data-lucide="play"></i>
            从上次进度继续
          </button>
          <a
            class="button button-quiet"
            href="${escapeHtml(track.sourceUrl)}"
            target="_blank"
            rel="noreferrer"
          >
            <i data-lucide="external-link"></i>
            ${track.id === "data" ? "课程说明" : "Microsoft 课程页"}
          </a>
          <a
            class="button button-quiet"
            href="${escapeHtml(track.repoUrl)}"
            target="_blank"
            rel="noreferrer"
          >
            <i data-lucide="folder-code"></i>
            配套代码
          </a>
        </div>
      </section>

      <section class="stats-grid" aria-label="${escapeHtml(track.shortTitle)}统计">
        <article class="stat-card">
          <span>内容数量</span>
          <strong>${track.lessonCount}</strong>
        </article>
        <article class="stat-card">
          <span>已完成</span>
          <strong>${trackProgress.complete}</strong>
        </article>
        <article class="stat-card">
          <span>完成进度</span>
          <strong>${trackProgress.percent}%</strong>
        </article>
        <article class="stat-card">
          <span>${hasVideo ? "视频时长" : "练习形式"}</span>
          <strong>${hasVideo ? formatDuration(track.durationMs) : "Jupyter"}</strong>
        </article>
      </section>

      ${renderToolbar(track, filteredLessons.length)}

      ${
        cards
          ? `<section class="lesson-grid">${cards}</section>`
          : `
            <section class="empty-state">
              <div>
                <i data-lucide="filter-x"></i>
                <h2>当前筛选没有内容</h2>
                <p>切换到“全部”即可查看完整课程列表。</p>
              </div>
            </section>
          `
      }
    `;
  }

  function render() {
    const scrollPosition = window.scrollY;
    renderNavigation();
    renderProgress();

    if (state.search.trim()) {
      renderSearchResults();
    } else if (state.activeTrack === "overview") {
      renderOverview();
    } else if (state.activeTrack === "assignments") {
      renderAssignments();
    } else {
      const track = courseData.tracks.find(
        (entry) => entry.id === state.activeTrack,
      );
      renderTrack(track);
    }

    renderIcons();
    requestAnimationFrame(() => window.scrollTo(0, scrollPosition));
  }

  function setTrack(trackId) {
    state.activeTrack = trackId;
    state.search = "";
    state.completionFilter = "all";
    searchInput.value = "";
    document.body.classList.remove("sidebar-open");
    render();
  }

  function toggleComplete(key) {
    if (progress[key]) {
      delete progress[key];
    } else {
      progress[key] = true;
    }
    saveProgress();
    render();
  }

  function clearCaptionTracks() {
    videoPlayer
      .querySelectorAll("track")
      .forEach((track) => track.remove());
  }

  function addCaptionTracks(lesson) {
    clearCaptionTracks();

    const captions = lesson.captions || {};
    if (captions["zh-cn"]) {
      const chineseTrack = document.createElement("track");
      chineseTrack.kind = "subtitles";
      chineseTrack.label = "中文";
      chineseTrack.srclang = "zh-CN";
      chineseTrack.src = captions["zh-cn"];
      chineseTrack.default = true;
      videoPlayer.appendChild(chineseTrack);
    }

    if (captions["en-us"]) {
      const englishTrack = document.createElement("track");
      englishTrack.kind = "subtitles";
      englishTrack.label = "English";
      englishTrack.srclang = "en-US";
      englishTrack.src = captions["en-us"];
      videoPlayer.appendChild(englishTrack);
    }
  }

  function applySubtitleMode(mode) {
    state.subtitleLanguage = mode;

    for (const track of videoPlayer.textTracks) {
      const language = (track.language || "").toLowerCase();
      const shouldShow =
        (mode === "zh" && language.startsWith("zh")) ||
        (mode === "en" && language.startsWith("en"));
      track.mode = shouldShow ? "showing" : "disabled";
    }

    videoSubtitleControl
      .querySelectorAll("[data-subtitle]")
      .forEach((button) => {
        button.classList.toggle(
          "active",
          button.dataset.subtitle === mode,
        );
      });
  }

  function openLesson(key) {
    const item = lessonIndex.get(key);
    if (!item?.videoUrl) {
      return;
    }

    videoTitle.textContent = item.title;
    videoKicker.textContent =
      item.track.id === "basics"
        ? `Python 基础 · 第 ${item.number} 课`
        : `Python 进阶 · 第 ${item.number} 节`;
    videoDescription.textContent = `${item.track.title} · ${formatClock(
      item.durationMs,
    )}`;
    videoSource.href = item.pageUrl;
    videoPlayer.poster = item.thumbnail;
    addCaptionTracks(item);
    videoPlayer.src = item.videoUrl;
    videoPlayer.load();
    videoOverlay.classList.add("open");
    document.body.style.overflow = "hidden";
    videoClose.focus();
    applySubtitleMode(state.subtitleLanguage);
    videoPlayer.addEventListener(
      "loadedmetadata",
      () => applySubtitleMode(state.subtitleLanguage),
      { once: true },
    );
    videoPlayer.play().catch(() => {});
  }

  function closeVideo() {
    videoPlayer.pause();
    videoPlayer.removeAttribute("src");
    videoPlayer.removeAttribute("poster");
    clearCaptionTracks();
    videoPlayer.load();
    videoOverlay.classList.remove("open");
    document.body.style.overflow = "";
  }

  function continueTrack(trackId) {
    const track = courseData.tracks.find((entry) => entry.id === trackId);
    const lesson =
      track.lessons.find((entry) => !isLessonComplete(track, entry)) ||
      track.lessons[0];

    if (!lesson) {
      return;
    }

    if (lesson.videoUrl) {
      openLesson(lessonKey(track.id, lesson));
      return;
    }

    window.open(lesson.href, "_blank", "noopener,noreferrer");
  }

  function openAssignment(assignmentId, mode = "task") {
    const assignment = courseData.assignments.groups.find(
      (entry) => entry.id === assignmentId,
    );
    if (!assignment) {
      return;
    }

    state.activeTrack = "assignments";
    state.search = "";
    state.selectedAssignment = assignmentId;
    state.codeMode =
      mode === "solution" && assignment.solutionFile ? "solution" : "task";
    searchInput.value = "";
    render();
    requestAnimationFrame(() => {
      document
        .querySelector("#assignment-viewer")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  function closeAssignmentViewer() {
    state.selectedAssignment = "";
    render();
  }

  async function copyAssignmentCode(assignmentId, button) {
    const assignment = courseData.assignments.groups.find(
      (entry) => entry.id === assignmentId,
    );
    const file =
      assignment?.files.find((entry) => entry.role === state.codeMode) ||
      assignment?.taskFile;

    if (!file) {
      return;
    }

    try {
      await navigator.clipboard.writeText(file.code);
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = file.code;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      textarea.remove();
    }

    const original = button.innerHTML;
    button.innerHTML = '<i data-lucide="check"></i>已复制';
    renderIcons();
    window.setTimeout(() => {
      if (button.isConnected) {
        button.innerHTML = original;
        renderIcons();
      }
    }, 1500);
  }

  document.addEventListener("click", (event) => {
    const navButton = event.target.closest("[data-track]");
    if (navButton && navButton.classList.contains("track-nav-button")) {
      setTrack(navButton.dataset.track);
      return;
    }

    const openTrack = event.target.closest("[data-open-track]");
    if (openTrack) {
      setTrack(openTrack.dataset.openTrack);
      return;
    }

    const playButton = event.target.closest('[data-action="play"]');
    if (playButton) {
      openLesson(playButton.dataset.key);
      return;
    }

    const completeButton = event.target.closest(
      '[data-action="toggle-complete"]',
    );
    if (completeButton) {
      toggleComplete(completeButton.dataset.key);
      return;
    }

    const filterButton = event.target.closest("[data-completion-filter]");
    if (filterButton) {
      state.completionFilter = filterButton.dataset.completionFilter;
      render();
      return;
    }

    const subtitleButton = event.target.closest("[data-subtitle]");
    if (subtitleButton) {
      applySubtitleMode(subtitleButton.dataset.subtitle);
      return;
    }

    const codeModeButton = event.target.closest("[data-code-mode]");
    if (codeModeButton) {
      openAssignment(
        codeModeButton.dataset.assignment,
        codeModeButton.dataset.codeMode,
      );
      return;
    }

    const closeAssignmentButton = event.target.closest(
      '[data-action="close-assignment"]',
    );
    if (closeAssignmentButton) {
      closeAssignmentViewer();
      return;
    }

    const copyCodeButton = event.target.closest(
      '[data-action="copy-code"]',
    );
    if (copyCodeButton) {
      copyAssignmentCode(
        copyCodeButton.dataset.assignment,
        copyCodeButton,
      );
      return;
    }

    const continueButton = event.target.closest(
      '[data-action="continue-track"]',
    );
    if (continueButton) {
      continueTrack(continueButton.dataset.track);
    }
  });

  searchInput.addEventListener("input", (event) => {
    state.search = event.target.value;
    state.completionFilter = "all";
    render();
  });

  document.addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
      event.preventDefault();
      searchInput.focus();
      searchInput.select();
    }

    if (event.key === "Escape" && videoOverlay.classList.contains("open")) {
      closeVideo();
    }
  });

  document.querySelector("#sidebar-toggle").addEventListener("click", () => {
    document.body.classList.add("sidebar-open");
  });

  document.querySelector("#sidebar-close").addEventListener("click", () => {
    document.body.classList.remove("sidebar-open");
  });

  document
    .querySelector("#sidebar-backdrop")
    .addEventListener("click", () => {
      document.body.classList.remove("sidebar-open");
    });

  videoClose.addEventListener("click", closeVideo);
  videoOverlay.addEventListener("click", (event) => {
    if (event.target === videoOverlay) {
      closeVideo();
    }
  });

  window.addEventListener("pagehide", () => {
    videoPlayer.pause();
  });

  render();
})();
